-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: loan_soft
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auditoria`
--

DROP TABLE IF EXISTS `auditoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `tabla_afectada` varchar(100) NOT NULL,
  `tipo_operacion` varchar(50) NOT NULL,
  `registro_id` int(11) DEFAULT NULL,
  `valores_anteriores` text DEFAULT NULL,
  `valores_nuevos` text DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `request_id` varchar(36) DEFAULT NULL,
  `resultado` enum('ok','fallido') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `ix_auditoria_id` (`id`),
  KEY `idx_auditoria_fecha` (`fecha`),
  KEY `idx_auditoria_tipo_fecha` (`tipo_operacion`,`fecha`),
  CONSTRAINT `auditoria_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria`
--

LOCK TABLES `auditoria` WRITE;
/*!40000 ALTER TABLE `auditoria` DISABLE KEYS */;
INSERT INTO `auditoria` VALUES (1,1,'prestamos','CREATE',1,NULL,'{\"cliente_id\": 1, \"capital_prestado\": 1000000.0, \"porcentaje_interes\": 2.5, \"numero_cuotas\": 6, \"monto_total\": 1150000.0, \"estado\": \"activo\"}','Préstamo creado para cliente Carlos Rodríguez',NULL,'2026-09-21 15:16:08',NULL,NULL,NULL),(2,1,'movimientos_capital','CREATE',3,NULL,'{\"tipo_movimiento\": \"inversion\", \"descripcion\": \"Capital inicial\", \"valor\": 5555560.0, \"fecha\": \"2026-10-08\"}','Movimiento de caja registrado: Capital inicial','127.0.0.1','2026-10-08 22:12:56',NULL,NULL,NULL),(3,1,'prestamos','CREATE',2,NULL,'{\"cliente_id\": 2, \"capital_prestado\": 1000000.0, \"porcentaje_interes\": 2.5, \"numero_cuotas\": 6, \"monto_total\": 1150000.0, \"estado\": \"activo\"}','Préstamo creado para cliente Camilo','127.0.0.1','2026-10-08 22:24:19',NULL,NULL,NULL),(4,1,'pagos','CREATE',1,NULL,'{\"cuota_id\": 7, \"referencia_recibo\": \"REC-20261008-A99E4D\", \"monto_pagado\": 191667.0, \"capital_pagado\": 166667.0, \"interes_pagado\": 25000.0, \"mora_pagada\": 0.0, \"fecha_pago\": \"2026-10-08\"}','Pago registrado para cuota #1 con Recibo: REC-20261008-A99E4D','127.0.0.1','2026-10-08 22:26:47',NULL,NULL,NULL),(5,1,'pagos','CREATE',2,NULL,'{\"cuota_id\": 8, \"referencia_recibo\": \"REC-20261008-D41496\", \"monto_pagado\": 191667.0, \"capital_pagado\": 166667.0, \"interes_pagado\": 25000.0, \"mora_pagada\": 0.0, \"fecha_pago\": \"2026-10-08\"}','Pago registrado para cuota #2 con Recibo: REC-20261008-D41496','127.0.0.1','2026-10-08 22:29:15',NULL,NULL,NULL),(6,1,'moras','CREATE',1,NULL,'{\"cuota_id\": 2, \"prestamo_id\": 1, \"valor\": 1916.67, \"estado\": \"generada\"}','Mora generada automáticamente para cuota #2',NULL,'2026-10-08 22:54:09',NULL,NULL,NULL),(7,1,'plantillas_mensaje','CREATE',1,NULL,'{\"clave\": \"solicitud_pago\", \"canal\": \"whatsapp\"}','Plantilla \'Aviso\' creada','127.0.0.1','2026-10-09 00:04:00',NULL,NULL,NULL),(8,1,'moras','CREATE',2,NULL,'{\"cuota_id\": 1, \"prestamo_id\": 1, \"valor\": 1916.67, \"estado\": \"generada\"}','Mora generada automáticamente para cuota #1',NULL,'2026-10-12 21:57:56',NULL,NULL,NULL),(9,NULL,'solicitudes_prestamo','CREATE',1,NULL,'{\"cliente_id\": 3, \"monto_solicitado\": 1200000.0, \"plazo_cuotas\": 6, \"estado\": \"pendiente\", \"origen\": \"formulario_publico\"}','Solicitud pública #1 de Andres Jaramillo (formulario web)','127.0.0.1','2026-10-12 22:23:49',NULL,NULL,NULL),(10,1,'solicitudes_prestamo','UPDATE',1,'{\"estado\": \"pendiente\"}','{\"estado\": \"aprobada\", \"motivo\": \"Se aprueba solicitud de prestamo\", \"puntaje_scoring\": 600.0}','Solicitud #1 aprobada','127.0.0.1','2026-10-12 22:27:08',NULL,NULL,NULL),(11,1,'prestamos','CREATE',3,NULL,'{\"cliente_id\": 3, \"capital_prestado\": 1200000.0, \"porcentaje_interes\": 2.5, \"numero_cuotas\": 6, \"monto_total\": 1380000.0, \"estado\": \"activo\"}','Préstamo creado para cliente Andres Jaramillo','127.0.0.1','2026-10-12 22:29:40',NULL,NULL,NULL),(12,1,'configuracion_sistema','UPDATE',4,'{\"valor\": \"porcentaje\"}','{\"valor\": \"fijo\"}','Actualización del parámetro \'mora_tipo\'','127.0.0.1','2026-10-30 16:14:43',NULL,NULL,NULL),(13,1,'configuracion_sistema','UPDATE',1,'{\"valor\": \"1.0\"}','{\"valor\": \"1.0\"}','Actualización del parámetro \'tasa_mora_diaria\'','127.0.0.1','2026-10-30 16:22:35',NULL,NULL,NULL),(14,1,'configuracion_sistema','UPDATE',1,'{\"valor\": \"1.0\"}','{\"valor\": \"1.0\"}','Actualización del parámetro \'tasa_mora_diaria\'','127.0.0.1','2026-10-30 16:24:18',NULL,NULL,NULL),(15,1,'configuracion_sistema','UPDATE',1,'{\"valor\": \"1.0\"}','{\"valor\": \"1.0\"}','Actualización del parámetro \'tasa_mora_diaria\'','127.0.0.1','2026-10-30 16:24:18',NULL,NULL,NULL),(16,1,'configuracion_sistema','UPDATE',1,'{\"valor\": \"1.0\"}','{\"valor\": \"1.0\"}','Actualización del parámetro \'tasa_mora_diaria\'','127.0.0.1','2026-10-30 16:24:19',NULL,NULL,NULL),(17,1,'configuracion_sistema','UPDATE',1,'{\"valor\": \"1.0\"}','{\"valor\": \"1.0\"}','Actualización del parámetro \'tasa_mora_diaria\'','127.0.0.1','2026-10-30 16:24:19',NULL,NULL,NULL),(18,1,'configuracion_sistema','UPDATE',1,'{\"valor\": \"1.0\"}','{\"valor\": \"1.0\"}','Actualización del parámetro \'tasa_mora_diaria\'','127.0.0.1','2026-10-30 16:24:20',NULL,NULL,NULL),(19,1,'configuracion_sistema','UPDATE',1,'{\"valor\": \"1.0\"}','{\"valor\": \"1.0\"}','Actualización del parámetro \'tasa_mora_diaria\'','127.0.0.1','2026-10-30 16:24:20',NULL,NULL,NULL),(20,1,'configuracion_sistema','UPDATE',1,'{\"valor\": \"1.0\"}','{\"valor\": \"3000\"}','Actualización del parámetro \'tasa_mora_diaria\'','127.0.0.1','2026-10-30 16:28:17',NULL,NULL,NULL),(21,1,'prestamos','CREATE',4,NULL,'{\"cliente_id\": 4, \"capital_prestado\": 100000.0, \"porcentaje_interes\": 2.5, \"numero_cuotas\": 4, \"monto_total\": 110000.0, \"estado\": \"activo\"}','Préstamo creado para cliente camiloP','127.0.0.1','2026-10-30 16:39:14',NULL,NULL,NULL),(22,1,'prestamos','CREATE',5,NULL,'{\"cliente_id\": 3, \"capital_prestado\": 120000.0, \"porcentaje_interes\": 2.5, \"numero_cuotas\": 4, \"monto_total\": 132000.0, \"estado\": \"activo\"}','Préstamo creado para cliente Andres Jaramillo','127.0.0.1','2026-10-30 16:40:14',NULL,NULL,NULL),(23,1,'configuracion_sistema','UPDATE',5,'{\"valor\": \"0\"}','{\"valor\": \"3000\"}','Actualización del parámetro \'mora_valor_fijo\'','127.0.0.1','2026-11-02 23:23:47',NULL,NULL,NULL),(24,1,'pagos','CREATE',3,NULL,'{\"cuota_id\": 1, \"referencia_recibo\": \"REC-20261102-D27323\", \"monto_pagado\": 191667.0, \"capital_pagado\": 166667.0, \"interes_pagado\": 25000.0, \"mora_pagada\": 0.0, \"fecha_pago\": \"2026-11-02\"}','Pago registrado para cuota #1 con Recibo: REC-20261102-D27323','127.0.0.1','2026-11-02 23:30:08',NULL,NULL,NULL),(25,1,'moras','CREATE',3,NULL,'{\"cuota_id\": 13, \"prestamo_id\": 3, \"valor\": 30000.0, \"estado\": \"generada\"}','Mora generada automáticamente para cuota #13',NULL,'2026-11-09 17:33:16',NULL,NULL,NULL),(26,1,'moras','CREATE',4,NULL,'{\"cuota_id\": 23, \"prestamo_id\": 5, \"valor\": 15000.0, \"estado\": \"generada\"}','Mora generada automáticamente para cuota #23',NULL,'2026-11-09 17:33:17',NULL,NULL,NULL),(27,2,'plantillas_mensaje','CREATE',2,NULL,'{\"clave\": \"solicitud_pago_correo\", \"canal\": \"email\"}','Plantilla \'Aviso Correo\' creada','127.0.0.1','2026-11-09 17:38:24',NULL,NULL,NULL),(28,3,'movimientos_capital','CREATE',11,NULL,'{\"tipo_movimiento\": \"inversion\", \"descripcion\": \"Primer registro\", \"valor\": 100000.0, \"fecha\": \"2026-11-09\"}','Movimiento de caja registrado: Primer registro','127.0.0.1','2026-11-09 20:38:32',NULL,NULL,NULL),(29,3,'movimientos_capital','CREATE',12,NULL,'{\"tipo_movimiento\": \"inversion\", \"descripcion\": \"Capital inicial\", \"valor\": 1000000.0, \"fecha\": \"2026-11-09\"}','Movimiento de caja registrado: Capital inicial','127.0.0.1','2026-11-09 20:54:16',NULL,NULL,NULL),(30,1,'prestamos','CREATE',6,NULL,'{\"cliente_id\": 4, \"capital_prestado\": 100000.0, \"porcentaje_interes\": 2.5, \"numero_cuotas\": 4, \"monto_total\": 105000.0, \"estado\": \"activo\"}','Préstamo creado para cliente camiloP','127.0.0.1','2026-11-09 21:39:02',NULL,NULL,NULL),(31,2,'configuracion_sistema','UPDATE',1,'{\"valor\": \"3000\"}','{\"valor\": \"2\", \"origen\": \"usuario\"}','Actualización del parámetro \'tasa_mora_diaria\'','127.0.0.1','2026-11-10 20:40:02',NULL,NULL,NULL),(32,2,'movimientos_capital','CREATE',14,NULL,'{\"tipo_movimiento\": \"inversion\", \"descripcion\": \"Capital inicial\", \"valor\": 2000000.0, \"fecha\": \"2026-11-18\"}','Movimiento de caja registrado: Capital inicial','127.0.0.1','2026-11-18 16:36:04',NULL,NULL,NULL),(33,2,'prestamos','CREATE',7,NULL,'{\"cliente_id\": 8, \"capital_prestado\": 1000000.0, \"porcentaje_interes\": 3.0, \"numero_cuotas\": 6, \"monto_total\": 1180000.0, \"estado\": \"activo\"}','Préstamo creado para cliente Prueba de fuego','127.0.0.1','2026-11-18 16:42:05',NULL,NULL,NULL),(34,2,'pagos','CREATE',4,NULL,'{\"cuota_id\": 31, \"referencia_recibo\": \"REC-20261118-5D9BC9\", \"monto_pagado\": 30000.0, \"capital_pagado\": 0.0, \"interes_pagado\": 30000.0, \"mora_pagada\": 0.0, \"fecha_pago\": \"2026-11-18\"}','Pago registrado para cuota #1 con Recibo: REC-20261118-5D9BC9','127.0.0.1','2026-11-18 16:43:39',NULL,NULL,NULL),(35,1,'usuarios','login',1,NULL,NULL,'Inicio de sesión exitoso: admin@test.com','127.0.0.1','2026-11-18 21:36:17','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','f2a4074e-779b-4b20-8598-cf8f5747476d','ok'),(36,1,'ejecuciones_proceso','ejecucion_proceso',1,NULL,NULL,'Ejecución manual solicitada: respaldo_diario_bd','127.0.0.1','2026-11-18 22:14:40','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','8c453b8d-9ee3-4787-90b2-474264f49218','ok'),(37,1,'ejecuciones_proceso','respaldo_manual',1,NULL,NULL,'Respaldo manual solicitado desde el Backoffice','127.0.0.1','2026-11-18 22:14:40','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36','8c453b8d-9ee3-4787-90b2-474264f49218','ok');
/*!40000 ALTER TABLE `auditoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capital`
--

DROP TABLE IF EXISTS `capital`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capital` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `monto_total` float DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_capital_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capital`
--

LOCK TABLES `capital` WRITE;
/*!40000 ALTER TABLE `capital` DISABLE KEYS */;
INSERT INTO `capital` VALUES (1,12635700,'2026-11-09 21:39:02',1),(2,1000000,'2026-11-18 16:42:05',2),(3,1000000,'2026-11-09 20:54:16',3);
/*!40000 ALTER TABLE `capital` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `cedula` varchar(20) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `persona_referencia` varchar(100) DEFAULT NULL,
  `telefono_referencia` varchar(20) DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  `estado` enum('activo','inactivo') DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_clientes_id` (`id`),
  KEY `ix_clientes_cedula` (`cedula`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'Carlos Rodríguez','123456789','3027440719','Calle 123 #45-67',NULL,NULL,NULL,'activo','2026-09-17 16:15:06','2026-10-09 00:03:18',NULL,1),(2,'Camilo','1107837695','3027440719','calle 22B #21-138','Andres Ramirez','3027665432',NULL,'activo','2026-10-08 22:13:19','2026-10-08 22:22:42',NULL,1),(3,'Andres Jaramillo','1107837654','3029981726',NULL,NULL,NULL,NULL,'activo','2026-10-12 22:23:49','2026-10-12 22:23:49','camilojara0000@gmail.com',1),(4,'camiloP','111111111',NULL,NULL,NULL,NULL,NULL,'activo','2026-10-30 16:35:09','2026-10-30 16:35:09','camilo@example.com',1),(5,'usuario uno','1111111111',NULL,NULL,NULL,NULL,NULL,'activo','2026-10-30 17:34:09','2026-10-30 17:34:09','usuario@example.com',2),(6,'juan','12121212',NULL,NULL,NULL,NULL,NULL,'activo','2026-11-09 16:52:41','2026-11-09 16:52:41','anonymousmillojara@gmail.com',2),(7,'Juan Andres Padilla','13131313','3027440719',NULL,NULL,NULL,NULL,'activo','2026-11-09 20:54:51','2026-11-09 20:54:51','camilojara0000@gmail.com',3),(8,'Prueba de fuego','1414141414','3027440719',NULL,NULL,NULL,NULL,'activo','2026-11-18 16:21:25','2026-11-18 16:21:25','prueba4@example.com',2);
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion_sistema`
--

DROP TABLE IF EXISTS `configuracion_sistema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuracion_sistema` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clave` varchar(100) NOT NULL,
  `valor` varchar(255) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `tipo_valor` varchar(50) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave` (`clave`),
  KEY `ix_configuracion_sistema_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion_sistema`
--

LOCK TABLES `configuracion_sistema` WRITE;
/*!40000 ALTER TABLE `configuracion_sistema` DISABLE KEYS */;
INSERT INTO `configuracion_sistema` VALUES (1,'tasa_mora_diaria','3000','Porcentaje de mora diaria por cuota vencida','float',1,'2026-09-17 16:15:06','2026-10-30 16:28:17',1),(2,'interes_minimo','2.5','Tasa de interés mínima por defecto para nuevos préstamos','float',1,'2026-09-17 16:15:06','2026-09-17 16:15:06',1),(3,'dias_gracia_mora','3','Días de gracia antes de aplicar mora','int',1,'2026-09-17 16:15:06','2026-09-17 16:15:06',1),(4,'mora_tipo','fijo','Modo de mora diaria: \'porcentaje\' o \'fijo\'','string',1,'2026-10-30 00:39:25','2026-10-30 16:14:43',1),(5,'mora_valor_fijo','3000','Valor fijo de mora por día cuando mora_tipo = \'fijo\'','float',1,'2026-10-30 00:39:25','2026-11-02 23:23:47',1),(6,'mora_tipo_calculo','simple','Tipo de cálculo de mora: \'simple\' (lineal) o \'compuesta\'','string',1,'2026-11-09 16:30:19','2026-11-09 16:30:19',1),(7,'sesiones_maximas','5','Sesiones activas simultáneas por usuario','int',1,'2026-11-18 21:35:40','2026-11-18 21:35:40',1),(8,'login_max_intentos','10','Intentos de login permitidos por ventana','int',1,'2026-11-18 21:35:40','2026-11-18 21:35:40',1),(9,'login_ventana_min','15','Ventana (minutos) del rate limit de login','int',1,'2026-11-18 21:35:40','2026-11-18 21:35:40',1),(10,'tokens_retencion_dias','30','Días de retención de tokens revocados','int',1,'2026-11-18 21:35:40','2026-11-18 21:35:40',1),(11,'errores_retencion_dias','180','Días de retención de errores resueltos/ignorados','int',1,'2026-11-18 21:35:40','2026-11-18 21:35:40',1),(12,'metricas_retencion_dias','180','Días de retención de métricas API','int',1,'2026-11-18 21:35:40','2026-11-18 21:35:40',1),(13,'idempotency_retencion_horas','48','Horas de retención de claves de idempotencia','int',1,'2026-11-18 21:35:40','2026-11-18 21:35:40',1),(14,'notificaciones_retencion_dias','90','Días de retención de notificaciones leídas (0=desactivado)','int',1,'2026-11-18 21:35:40','2026-11-18 21:35:40',1),(15,'envios_retencion_dias','180','Días de retención del log de envíos de mensajes','int',1,'2026-11-18 21:35:40','2026-11-18 21:35:40',1),(16,'auditoria_retencion_dias','0','Días de retención de auditoría (0=nunca se elimina)','int',1,'2026-11-18 21:35:40','2026-11-18 21:35:40',1),(17,'nombre_empresa','LoanSoft','Nombre de la empresa usado en PDFs, reportes, contratos, comprobantes y mensajes','string',1,'2026-11-18 22:04:03','2026-11-18 22:04:03',1);
/*!40000 ALTER TABLE `configuracion_sistema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion_usuario`
--

DROP TABLE IF EXISTS `configuracion_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuracion_usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `clave` varchar(100) NOT NULL,
  `valor` varchar(255) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `tipo_valor` varchar(50) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_config_usuario_usuario_clave` (`usuario_id`,`clave`),
  KEY `ix_configuracion_usuario_usuario_id` (`usuario_id`),
  KEY `ix_configuracion_usuario_clave` (`clave`),
  KEY `ix_configuracion_usuario_id` (`id`),
  CONSTRAINT `configuracion_usuario_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion_usuario`
--

LOCK TABLES `configuracion_usuario` WRITE;
/*!40000 ALTER TABLE `configuracion_usuario` DISABLE KEYS */;
INSERT INTO `configuracion_usuario` VALUES (1,2,'tasa_mora_diaria','2','Porcentaje de mora diaria por cuota vencida','float',1,'2026-11-10 20:40:02','2026-11-10 20:40:02');
/*!40000 ALTER TABLE `configuracion_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contratos`
--

DROP TABLE IF EXISTS `contratos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contratos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `solicitud_id` int(11) DEFAULT NULL,
  `prestamo_id` int(11) DEFAULT NULL,
  `estado` enum('emitido','en_firma','firmado','rechazado') DEFAULT NULL,
  `ruta_archivo` varchar(255) NOT NULL,
  `hash_documento` varchar(64) NOT NULL,
  `firmante_nombre` varchar(120) DEFAULT NULL,
  `firmante_documento` varchar(30) DEFAULT NULL,
  `fecha_emision` datetime DEFAULT NULL,
  `fecha_firma` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `solicitud_id` (`solicitud_id`),
  KEY `prestamo_id` (`prestamo_id`),
  KEY `ix_contratos_id` (`id`),
  CONSTRAINT `contratos_ibfk_1` FOREIGN KEY (`solicitud_id`) REFERENCES `solicitudes_prestamo` (`id`),
  CONSTRAINT `contratos_ibfk_2` FOREIGN KEY (`prestamo_id`) REFERENCES `prestamos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contratos`
--

LOCK TABLES `contratos` WRITE;
/*!40000 ALTER TABLE `contratos` DISABLE KEYS */;
INSERT INTO `contratos` VALUES (1,1,3,'firmado','contratos_guardados\\CONTRATO-SOL-000001-7c9e18ba.pdf','4b1b88f1f4f97910b1525dad5a22fb3d5676a4378f001c66c5944e4c7e4116fb','Andres Jaramillo','1107837695','2026-10-12 22:27:07','2026-10-12 22:29:00','2026-10-12 22:27:07','2026-10-12 22:29:41',1);
/*!40000 ALTER TABLE `contratos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ejecuciones_proceso`
--

DROP TABLE IF EXISTS `ejecuciones_proceso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ejecuciones_proceso` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tarea` varchar(80) NOT NULL,
  `origen` enum('programada','manual') DEFAULT NULL,
  `estado` enum('pendiente','en_ejecucion','completado','fallido','cancelado') DEFAULT NULL,
  `solicitado_por` int(11) DEFAULT NULL,
  `fecha_solicitud` datetime NOT NULL,
  `inicio` datetime DEFAULT NULL,
  `fin` datetime DEFAULT NULL,
  `duracion_ms` int(11) DEFAULT NULL,
  `intentos` int(11) NOT NULL,
  `resultado` text DEFAULT NULL,
  `error_mensaje` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `solicitado_por` (`solicitado_por`),
  KEY `ix_ejecuciones_proceso_tarea` (`tarea`),
  KEY `ix_ejecuciones_proceso_estado` (`estado`),
  KEY `ix_ejecuciones_proceso_id` (`id`),
  KEY `idx_ejecuciones_tarea_fecha` (`tarea`,`fecha_solicitud`),
  CONSTRAINT `ejecuciones_proceso_ibfk_1` FOREIGN KEY (`solicitado_por`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ejecuciones_proceso`
--

LOCK TABLES `ejecuciones_proceso` WRITE;
/*!40000 ALTER TABLE `ejecuciones_proceso` DISABLE KEYS */;
INSERT INTO `ejecuciones_proceso` VALUES (1,'respaldo_diario_bd','manual','en_ejecucion',1,'2026-11-18 22:14:40','2026-11-18 22:14:40',NULL,NULL,1,NULL,NULL);
/*!40000 ALTER TABLE `ejecuciones_proceso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `envios_mensaje`
--

DROP TABLE IF EXISTS `envios_mensaje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `envios_mensaje` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canal` enum('email','sms','whatsapp') DEFAULT NULL,
  `destinatario` varchar(120) NOT NULL,
  `asunto` varchar(200) DEFAULT NULL,
  `cuerpo` text DEFAULT NULL,
  `plantilla_id` int(11) DEFAULT NULL,
  `estado` enum('enviado','omitido','fallido') DEFAULT NULL,
  `motivo` varchar(255) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  `dedupe_clave` varchar(120) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plantilla_id` (`plantilla_id`),
  KEY `ix_envios_mensaje_id` (`id`),
  CONSTRAINT `envios_mensaje_ibfk_1` FOREIGN KEY (`plantilla_id`) REFERENCES `plantillas_mensaje` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `envios_mensaje`
--

LOCK TABLES `envios_mensaje` WRITE;
/*!40000 ALTER TABLE `envios_mensaje` DISABLE KEYS */;
INSERT INTO `envios_mensaje` VALUES (1,'sms','3027440719','Aviso de mora','Hola Carlos, la cuota 1 acumula $1,917 de mora por 1 día(s) de atraso. Referencia: .',NULL,'omitido','Proveedor de sms no configurado','2026-10-12 21:57:57','mora_aviso:cuota:1:2026-10-12',1),(2,'sms','3029981726','Bienvenido','Hola Andres, bienvenido(a). Tu registro quedó completo. Estamos listos para ayudarte con tu préstamo.',NULL,'omitido','Proveedor de sms no configurado','2026-10-12 22:23:49','cliente_bienvenida:cliente:3',1),(3,'sms','3029981726','Solicitud de préstamo','Hola Andres, tu solicitud de préstamo por $1,200,000 fue aprobada. Motivo: Se aprueba solicitud de prestamo.',NULL,'omitido','Proveedor de sms no configurado','2026-10-12 22:27:08',NULL,1),(4,'email','admin@test.com','Préstamo #3 registrado','Hola Andres,\n\nSe registró el préstamo #3 por $1,200,000 a 6 cuotas.\n\nSaludos.',NULL,'fallido','Servidor de correo no disponible o error de envío','2026-10-12 22:29:40',NULL,1),(5,'email','admin@test.com','Préstamo #4 registrado','Hola camiloP,\n\nSe registró el préstamo #4 por $100,000 a 4 cuotas.\n\nSaludos.',NULL,'fallido','Servidor de correo no disponible o error de envío','2026-10-30 16:39:15',NULL,1),(6,'email','admin@test.com','Préstamo #5 registrado','Hola Andres,\n\nSe registró el préstamo #5 por $120,000 a 4 cuotas.\n\nSaludos.',NULL,'fallido','Servidor de correo no disponible o error de envío','2026-10-30 16:40:14',NULL,1),(7,'sms','3027440719','Pago recibido','Hola Carlos, recibimos tu pago de $191,667 por la cuota 1 (Recibo: REC-20261102-D27323). Gracias.',NULL,'omitido','Proveedor de sms no configurado','2026-11-02 23:30:08','pago_confirmado:pago:3',1),(8,'sms','3029981726','Aviso de mora','Hola Andres, la cuota 1 acumula $30,000 de mora por 13 día(s) de atraso. Referencia: REF-P3C1-PN8I.',NULL,'omitido','Proveedor de sms no configurado','2026-11-09 17:33:16','mora_aviso:cuota:13:2026-11-09',1),(9,'sms','3029981726','Aviso de mora','Hola Andres, la cuota 1 acumula $15,000 de mora por 8 día(s) de atraso. Referencia: REF-P5C1-EUZK.',NULL,'omitido','Proveedor de sms no configurado','2026-11-09 17:33:17','mora_aviso:cuota:23:2026-11-09',1),(10,'email','camilojara0000@gmail.com','Recuerda pagar','Tu cuota sta proxima a vencer recuerda pagar',2,'fallido','Servidor de correo no disponible o error de envío','2026-11-09 17:44:49','recordatorio:proximos:14:2026-11-09',1),(11,'email','camilojara0000@gmail.com','Recuerda pagar','Tu cuota sta proxima a vencer recuerda pagar',2,'fallido','Servidor de correo no disponible o error de envío','2026-11-09 20:21:55','recordatorio:proximos:14:2026-11-09',1),(12,'email','camilojara0000@gmail.com','Recuerda pagar','Tu cuota sta proxima a vencer recuerda pagar',2,'fallido','Servidor de correo no disponible o error de envío','2026-11-09 20:22:10','recordatorio:proximos:14:2026-11-09',1),(13,'email','camilojara0000@gmail.com','Recuerda pagar','Tu cuota sta proxima a vencer recuerda pagar',2,'fallido','Servidor de correo no disponible o error de envío','2026-11-09 20:23:26','recordatorio:proximos:14:2026-11-09',1),(14,'email','camilojara0000@gmail.com','Recuerda pagar','Tu cuota sta proxima a vencer recuerda pagar',2,'fallido','Servidor de correo no disponible o error de envío','2026-11-09 20:24:09','recordatorio:proximos:14:2026-11-09',1),(15,'email','camilojara0000@gmail.com','Recuerda pagar','Tu cuota sta proxima a vencer recuerda pagar',2,'enviado',NULL,'2026-11-09 20:30:58','recordatorio:proximos:14:2026-11-09',1),(16,'sms','3027440719','Bienvenido','Hola Juan, bienvenido(a). Tu registro quedó completo. Estamos listos para ayudarte con tu préstamo.',NULL,'omitido','Proveedor de sms no configurado','2026-11-09 20:54:51','cliente_bienvenida:cliente:7',1),(17,'email','admin@test.com','Préstamo #6 registrado','Hola camiloP,\n\nSe registró el préstamo #6 por $100,000 a 4 cuotas.\n\nSaludos.',NULL,'enviado',NULL,'2026-11-09 21:39:03',NULL,1),(18,'sms','3027440719','Bienvenido','Hola Prueba, bienvenido(a). Tu registro quedó completo. Estamos listos para ayudarte con tu préstamo.',NULL,'omitido','Proveedor de sms no configurado','2026-11-18 16:21:25','cliente_bienvenida:cliente:8',1),(19,'email','camilojara0000@gmail.com','Préstamo #7 registrado','Hola Prueba,\n\nSe registró el préstamo #7 por $1,000,000 a 6 cuotas.\n\nSaludos.',NULL,'enviado',NULL,'2026-11-18 16:42:07',NULL,1),(20,'sms','3027440719','Pago recibido','Hola Prueba, recibimos tu pago de $30,000 por la cuota 1 (Recibo: REC-20261118-5D9BC9). Gracias.',NULL,'omitido','Proveedor de sms no configurado','2026-11-18 16:43:39','pago_confirmado:pago:4',1);
/*!40000 ALTER TABLE `envios_mensaje` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `errores_app`
--

DROP TABLE IF EXISTS `errores_app`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `errores_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `origen` enum('backend','frontend') DEFAULT NULL,
  `nivel` enum('error','critico') DEFAULT NULL,
  `tipo_exception` varchar(150) NOT NULL,
  `mensaje` text NOT NULL,
  `stack_trace` text DEFAULT NULL,
  `endpoint` varchar(200) DEFAULT NULL,
  `componente` varchar(200) DEFAULT NULL,
  `metodo_http` varchar(10) DEFAULT NULL,
  `status_code` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `request_id` varchar(36) DEFAULT NULL,
  `version` varchar(20) DEFAULT NULL,
  `fingerprint` varchar(64) NOT NULL,
  `ocurrencias` int(11) NOT NULL,
  `primera_ocurrencia` datetime NOT NULL,
  `ultima_ocurrencia` datetime NOT NULL,
  `estado` enum('abierto','en_seguimiento','resuelto','ignorado') DEFAULT NULL,
  `responsable_id` int(11) DEFAULT NULL,
  `resolucion` text DEFAULT NULL,
  `fecha_resolucion` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `responsable_id` (`responsable_id`),
  KEY `ix_errores_app_request_id` (`request_id`),
  KEY `ix_errores_app_usuario_id` (`usuario_id`),
  KEY `ix_errores_app_estado` (`estado`),
  KEY `ix_errores_app_fingerprint` (`fingerprint`),
  KEY `ix_errores_app_id` (`id`),
  KEY `idx_errores_app_ultima` (`ultima_ocurrencia`),
  CONSTRAINT `errores_app_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `errores_app_ibfk_2` FOREIGN KEY (`responsable_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `errores_app`
--

LOCK TABLES `errores_app` WRITE;
/*!40000 ALTER TABLE `errores_app` DISABLE KEYS */;
INSERT INTO `errores_app` VALUES (1,'backend','error','TypeError','unsupported operand type(s) for /: \'float\' and \'decimal.Decimal\'','Traceback (most recent call last):\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\middleware\\errors.py\", line 164, in __call__\n    await self.app(scope, receive, _send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\middleware\\base.py\", line 191, in __call__\n    with recv_stream, send_stream, collapse_excgroups():\n                                   ~~~~~~~~~~~~~~~~~~^^\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\contextlib.py\", line 162, in __exit__\n    self.gen.throw(value)\n    ~~~~~~~~~~~~~~^^^^^^^\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\_utils.py\", line 87, in collapse_excgroups\n    raise exc\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\middleware\\base.py\", line 193, in __call__\n    response = await self.dispatch_func(request, call_next)\n               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"C:\\Proyectos\\Prestamos\\prestamos_backend\\app\\main.py\", line 164, in cabeceras_seguridad\n    respuesta = await call_next(request)\n                ^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\middleware\\base.py\", line 168, in call_next\n    raise app_exc from app_exc.__cause__ or app_exc.__context__\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\middleware\\base.py\", line 144, in coro\n    await self.app(scope, receive_or_disconnect, send_no_error)\n  File \"C:\\Proyectos\\Prestamos\\prestamos_backend\\app\\core\\observabilidad.py\", line 252, in __call__\n    await self.app(scope, receive, send_wrapper)\n  File \"C:\\Proyectos\\Prestamos\\prestamos_backend\\app\\core\\middleware.py\", line 47, in __call__\n    await self.app(scope, receive, send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\middleware\\cors.py\", line 95, in __call__\n    await self.simple_response(scope, receive, send, request_headers=headers)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\middleware\\cors.py\", line 153, in simple_response\n    await self.app(scope, receive, send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\middleware\\exceptions.py\", line 63, in __call__\n    await wrap_app_handling_exceptions(self.app, conn)(scope, receive, send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\_exception_handler.py\", line 53, in wrapped_app\n    raise exc\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\_exception_handler.py\", line 42, in wrapped_app\n    await app(scope, receive, sender)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\fastapi\\middleware\\asyncexitstack.py\", line 18, in __call__\n    await self.app(scope, receive, send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\routing.py\", line 716, in __call__\n    await self.middleware_stack(scope, receive, send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\routing.py\", line 736, in app\n    await route.handle(scope, receive, send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\routing.py\", line 290, in handle\n    await self.app(scope, receive, send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\fastapi\\routing.py\", line 130, in app\n    await wrap_app_handling_exceptions(app, request)(scope, receive, send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\_exception_handler.py\", line 53, in wrapped_app\n    raise exc\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\_exception_handler.py\", line 42, in wrapped_app\n    await app(scope, receive, sender)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\fastapi\\routing.py\", line 116, in app\n    response = await f(request)\n               ^^^^^^^^^^^^^^^^\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\fastapi\\routing.py\", line 670, in app\n    raw_response = await run_endpoint_function(\n                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n    ...<3 lines>...\n    )\n    ^\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\fastapi\\routing.py\", line 326, in run_endpoint_function\n    return await run_in_threadpool(dependant.call, **values)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\concurrency.py\", line 32, in run_in_threadpool\n    return await anyio.to_thread.run_sync(func)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\anyio\\to_thread.py\", line 63, in run_sync\n    return await get_async_backend().run_sync_in_worker_thread(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n        func, args, abandon_on_cancel=abandon_on_cancel, limiter=limiter\n        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n    )\n    ^\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\anyio\\_backends\\_asyncio.py\", line 2502, in run_sync_in_worker_thread\n    return await future\n           ^^^^^^^^^^^^\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\anyio\\_backends\\_asyncio.py\", line 986, in run\n    result = context.run(func, *args)\n  File \"C:\\Proyectos\\Prestamos\\prestamos_backend\\app\\routes\\backoffice\\dashboard.py\", line 29, in resumen\n    return service.resumen_dashboard(db)\n           ~~~~~~~~~~~~~~~~~~~~~~~~~^^^^\n  File \"C:\\Proyectos\\Prestamos\\prestamos_backend\\app\\services\\backoffice\\dashboard.py\", line 100, in resumen_dashboard\n    latencia_promedio = (float(latencia[0]) / latencia[1]) if latencia[1] else None\n                         ~~~~~~~~~~~~~~~~~~~^~~~~~~~~~~~~\nTypeError: unsupported operand type(s) for /: \'float\' and \'decimal.Decimal\'\n','/backoffice/dashboard',NULL,'GET',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36',NULL,'1.0.0','584e6602c454c87b00034c14656b09437834711682bfcc0171c12f7bb3d499ff',6,'2026-11-18 21:38:04','2026-11-18 21:56:36','abierto',NULL,NULL,NULL,'2026-11-18 21:38:04','2026-11-18 21:56:36'),(2,'backend','error','PydanticSerializationError','Unable to serialize unknown type: <class \'app.models.models.Auditoria\'>','Traceback (most recent call last):\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\middleware\\errors.py\", line 164, in __call__\n    await self.app(scope, receive, _send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\middleware\\base.py\", line 191, in __call__\n    with recv_stream, send_stream, collapse_excgroups():\n                                   ~~~~~~~~~~~~~~~~~~^^\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\contextlib.py\", line 162, in __exit__\n    self.gen.throw(value)\n    ~~~~~~~~~~~~~~^^^^^^^\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\_utils.py\", line 87, in collapse_excgroups\n    raise exc\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\middleware\\base.py\", line 193, in __call__\n    response = await self.dispatch_func(request, call_next)\n               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"C:\\Proyectos\\Prestamos\\prestamos_backend\\app\\main.py\", line 164, in cabeceras_seguridad\n    respuesta = await call_next(request)\n                ^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\middleware\\base.py\", line 168, in call_next\n    raise app_exc from app_exc.__cause__ or app_exc.__context__\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\middleware\\base.py\", line 144, in coro\n    await self.app(scope, receive_or_disconnect, send_no_error)\n  File \"C:\\Proyectos\\Prestamos\\prestamos_backend\\app\\core\\observabilidad.py\", line 252, in __call__\n    await self.app(scope, receive, send_wrapper)\n  File \"C:\\Proyectos\\Prestamos\\prestamos_backend\\app\\core\\middleware.py\", line 47, in __call__\n    await self.app(scope, receive, send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\middleware\\cors.py\", line 95, in __call__\n    await self.simple_response(scope, receive, send, request_headers=headers)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\middleware\\cors.py\", line 153, in simple_response\n    await self.app(scope, receive, send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\middleware\\exceptions.py\", line 63, in __call__\n    await wrap_app_handling_exceptions(self.app, conn)(scope, receive, send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\_exception_handler.py\", line 53, in wrapped_app\n    raise exc\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\_exception_handler.py\", line 42, in wrapped_app\n    await app(scope, receive, sender)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\fastapi\\middleware\\asyncexitstack.py\", line 18, in __call__\n    await self.app(scope, receive, send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\routing.py\", line 716, in __call__\n    await self.middleware_stack(scope, receive, send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\routing.py\", line 736, in app\n    await route.handle(scope, receive, send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\routing.py\", line 290, in handle\n    await self.app(scope, receive, send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\fastapi\\routing.py\", line 130, in app\n    await wrap_app_handling_exceptions(app, request)(scope, receive, send)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\_exception_handler.py\", line 53, in wrapped_app\n    raise exc\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\starlette\\_exception_handler.py\", line 42, in wrapped_app\n    await app(scope, receive, sender)\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\fastapi\\routing.py\", line 116, in app\n    response = await f(request)\n               ^^^^^^^^^^^^^^^^\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\fastapi\\routing.py\", line 691, in app\n    content = await serialize_response(\n              ^^^^^^^^^^^^^^^^^^^^^^^^^\n    ...<11 lines>...\n    )\n    ^\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\fastapi\\routing.py\", line 302, in serialize_response\n    return serializer(\n        value,\n    ...<5 lines>...\n        exclude_none=exclude_none,\n    )\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\fastapi\\_compat\\v2.py\", line 218, in serialize_json\n    return self._type_adapter.dump_json(\n           ~~~~~~~~~~~~~~~~~~~~~~~~~~~~^\n        value,\n        ^^^^^^\n    ...<5 lines>...\n        exclude_none=exclude_none,\n        ^^^^^^^^^^^^^^^^^^^^^^^^^^\n    )\n    ^\n  File \"C:\\Users\\CAMILO\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages\\pydantic\\type_adapter.py\", line 672, in dump_json\n    return self.serializer.to_json(\n           ~~~~~~~~~~~~~~~~~~~~~~~^\n        instance,\n        ^^^^^^^^^\n    ...<13 lines>...\n        context=context,\n        ^^^^^^^^^^^^^^^^\n    )\n    ^\npydantic_core._pydantic_core.PydanticSerializationError: Unable to serialize unknown type: <class \'app.models.models.Auditoria\'>\n','/backoffice/usuarios/{id}',NULL,'GET',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36',NULL,'1.0.0','a419d94915242fd59cfb71a9b6b02cc5b1b68a93a927c1c0f340377ffa20568e',2,'2026-11-18 22:07:26','2026-11-18 22:07:35','abierto',NULL,NULL,NULL,'2026-11-18 22:07:26','2026-11-18 22:07:35');
/*!40000 ALTER TABLE `errores_app` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eventos_agenda`
--

DROP TABLE IF EXISTS `eventos_agenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eventos_agenda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` enum('cuota_vence','recogida','cita','seguimiento','otro') DEFAULT NULL,
  `titulo` varchar(200) NOT NULL,
  `descripcion` varchar(500) DEFAULT NULL,
  `fecha` date NOT NULL,
  `hora_inicio` varchar(5) DEFAULT NULL,
  `hora_fin` varchar(5) DEFAULT NULL,
  `prestamo_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `tipo_cita_id` int(11) DEFAULT NULL,
  `estado` enum('pendiente','completado','cancelado','vencido') DEFAULT NULL,
  `observaciones` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prestamo_id` (`prestamo_id`),
  KEY `cliente_id` (`cliente_id`),
  KEY `tipo_cita_id` (`tipo_cita_id`),
  KEY `ix_eventos_agenda_id` (`id`),
  KEY `ix_eventos_agenda_fecha` (`fecha`),
  CONSTRAINT `eventos_agenda_ibfk_1` FOREIGN KEY (`prestamo_id`) REFERENCES `prestamos` (`id`),
  CONSTRAINT `eventos_agenda_ibfk_2` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`),
  CONSTRAINT `eventos_agenda_ibfk_3` FOREIGN KEY (`tipo_cita_id`) REFERENCES `tipos_cita` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eventos_agenda`
--

LOCK TABLES `eventos_agenda` WRITE;
/*!40000 ALTER TABLE `eventos_agenda` DISABLE KEYS */;
INSERT INTO `eventos_agenda` VALUES (1,'recogida','Recoger cuota en efectivo','domicilio calle 22B','2026-10-12','17:35','18:35',NULL,NULL,NULL,'completado',NULL,'2026-10-12 21:36:04',1),(2,'seguimiento','Recoger cuota de efectivo','calle 45 C','2026-10-13','17:50','18:50',2,2,NULL,'pendiente',NULL,'2026-10-12 21:49:03',1),(3,'cuota_vence','Vence cuota #1 - Andres','Cuota #1 de $230,000.00 del préstamo #3','2026-10-27',NULL,NULL,3,3,NULL,'pendiente',NULL,'2026-10-12 22:29:40',1),(4,'cuota_vence','Vence cuota #2 - Andres','Cuota #2 de $230,000.00 del préstamo #3','2026-11-11',NULL,NULL,3,3,NULL,'pendiente',NULL,'2026-10-12 22:29:40',1),(5,'cuota_vence','Vence cuota #3 - Andres','Cuota #3 de $230,000.00 del préstamo #3','2026-11-26',NULL,NULL,3,3,NULL,'pendiente',NULL,'2026-10-12 22:29:40',1),(6,'cuota_vence','Vence cuota #4 - Andres','Cuota #4 de $230,000.00 del préstamo #3','2026-12-11',NULL,NULL,3,3,NULL,'pendiente',NULL,'2026-10-12 22:29:40',1),(7,'cuota_vence','Vence cuota #5 - Andres','Cuota #5 de $230,000.00 del préstamo #3','2026-12-26',NULL,NULL,3,3,NULL,'pendiente',NULL,'2026-10-12 22:29:40',1),(8,'cuota_vence','Vence cuota #6 - Andres','Cuota #6 de $230,000.00 del préstamo #3','2027-01-10',NULL,NULL,3,3,NULL,'pendiente',NULL,'2026-10-12 22:29:40',1),(9,'cuota_vence','Vence cuota #1 - camiloP','Cuota #1 de $27,500.00 del préstamo #4','2026-11-30',NULL,NULL,4,4,NULL,'pendiente',NULL,'2026-10-30 16:39:15',1),(10,'cuota_vence','Vence cuota #2 - camiloP','Cuota #2 de $27,500.00 del préstamo #4','2026-12-30',NULL,NULL,4,4,NULL,'pendiente',NULL,'2026-10-30 16:39:15',1),(11,'cuota_vence','Vence cuota #3 - camiloP','Cuota #3 de $27,500.00 del préstamo #4','2027-01-30',NULL,NULL,4,4,NULL,'pendiente',NULL,'2026-10-30 16:39:15',1),(12,'cuota_vence','Vence cuota #4 - camiloP','Cuota #4 de $27,500.00 del préstamo #4','2027-02-28',NULL,NULL,4,4,NULL,'pendiente',NULL,'2026-10-30 16:39:15',1),(13,'cuota_vence','Vence cuota #1 - Andres','Cuota #1 de $33,000.00 del préstamo #5','2026-11-01',NULL,NULL,5,3,NULL,'pendiente',NULL,'2026-10-30 16:40:14',1),(14,'cuota_vence','Vence cuota #2 - Andres','Cuota #2 de $33,000.00 del préstamo #5','2026-12-01',NULL,NULL,5,3,NULL,'pendiente',NULL,'2026-10-30 16:40:14',1),(15,'cuota_vence','Vence cuota #3 - Andres','Cuota #3 de $33,000.00 del préstamo #5','2027-01-01',NULL,NULL,5,3,NULL,'pendiente',NULL,'2026-10-30 16:40:14',1),(16,'cuota_vence','Vence cuota #4 - Andres','Cuota #4 de $33,000.00 del préstamo #5','2027-02-01',NULL,NULL,5,3,NULL,'pendiente',NULL,'2026-10-30 16:40:14',1),(17,'cuota_vence','Vence cuota #1 - camiloP','Cuota #1 de $26,250.00 del préstamo #6','2026-11-24',NULL,NULL,6,4,NULL,'pendiente',NULL,'2026-11-09 21:39:04',1),(18,'cuota_vence','Vence cuota #2 - camiloP','Cuota #2 de $26,250.00 del préstamo #6','2026-12-09',NULL,NULL,6,4,NULL,'pendiente',NULL,'2026-11-09 21:39:04',1),(19,'cuota_vence','Vence cuota #3 - camiloP','Cuota #3 de $26,250.00 del préstamo #6','2026-12-24',NULL,NULL,6,4,NULL,'pendiente',NULL,'2026-11-09 21:39:04',1),(20,'cuota_vence','Vence cuota #4 - camiloP','Cuota #4 de $26,250.00 del préstamo #6','2027-01-08',NULL,NULL,6,4,NULL,'pendiente',NULL,'2026-11-09 21:39:04',1),(21,'cuota_vence','Vence cuota #1 - Prueba','Cuota #1 de $196,667.00 del préstamo #7','2026-12-18',NULL,NULL,7,8,NULL,'pendiente',NULL,'2026-11-18 16:42:07',2),(22,'cuota_vence','Vence cuota #2 - Prueba','Cuota #2 de $196,667.00 del préstamo #7','2027-01-18',NULL,NULL,7,8,NULL,'pendiente',NULL,'2026-11-18 16:42:07',2),(23,'cuota_vence','Vence cuota #3 - Prueba','Cuota #3 de $196,667.00 del préstamo #7','2027-02-18',NULL,NULL,7,8,NULL,'pendiente',NULL,'2026-11-18 16:42:07',2),(24,'cuota_vence','Vence cuota #4 - Prueba','Cuota #4 de $196,667.00 del préstamo #7','2027-03-18',NULL,NULL,7,8,NULL,'pendiente',NULL,'2026-11-18 16:42:07',2),(25,'cuota_vence','Vence cuota #5 - Prueba','Cuota #5 de $196,667.00 del préstamo #7','2027-04-18',NULL,NULL,7,8,NULL,'pendiente',NULL,'2026-11-18 16:42:07',2),(26,'cuota_vence','Vence cuota #6 - Prueba','Cuota #6 de $196,667.00 del préstamo #7','2027-05-18',NULL,NULL,7,8,NULL,'pendiente',NULL,'2026-11-18 16:42:07',2),(27,'cita','Recoger cuota en efectivo',NULL,'2026-11-23','14:00','14:30',7,8,2,'pendiente',NULL,'2026-11-18 16:46:46',2);
/*!40000 ALTER TABLE `eventos_agenda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `idempotency_keys`
--

DROP TABLE IF EXISTS `idempotency_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `idempotency_keys` (
  `key` varchar(255) NOT NULL,
  `response` text NOT NULL,
  `status_code` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`key`),
  KEY `ix_idempotency_keys_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `idempotency_keys`
--

LOCK TABLES `idempotency_keys` WRITE;
/*!40000 ALTER TABLE `idempotency_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `idempotency_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metodos_pago_prestamista`
--

DROP TABLE IF EXISTS `metodos_pago_prestamista`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metodos_pago_prestamista` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `banco` varchar(50) NOT NULL,
  `tipo_cuenta` varchar(50) DEFAULT NULL,
  `numero_cuenta` varchar(50) NOT NULL,
  `titular` varchar(100) NOT NULL,
  `documento_titular` varchar(20) DEFAULT NULL,
  `qr_code_url` varchar(255) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `ix_metodos_pago_prestamista_id` (`id`),
  CONSTRAINT `metodos_pago_prestamista_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metodos_pago_prestamista`
--

LOCK TABLES `metodos_pago_prestamista` WRITE;
/*!40000 ALTER TABLE `metodos_pago_prestamista` DISABLE KEYS */;
/*!40000 ALTER TABLE `metodos_pago_prestamista` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metricas_api`
--

DROP TABLE IF EXISTS `metricas_api`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `metricas_api` (
  `fecha_hora` datetime NOT NULL,
  `endpoint` varchar(200) NOT NULL,
  `metodo` varchar(10) NOT NULL,
  `status_code` int(11) NOT NULL,
  `conteo` int(11) NOT NULL,
  `latencia_ms_suma` float NOT NULL,
  `latencia_ms_max` float NOT NULL,
  PRIMARY KEY (`fecha_hora`,`endpoint`,`metodo`,`status_code`),
  UNIQUE KEY `uq_metricas_api_clave` (`fecha_hora`,`endpoint`,`metodo`,`status_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metricas_api`
--

LOCK TABLES `metricas_api` WRITE;
/*!40000 ALTER TABLE `metricas_api` DISABLE KEYS */;
INSERT INTO `metricas_api` VALUES ('2026-11-18 21:00:00','/auth/login','OPTIONS',200,1,0.8962,0.8962),('2026-11-18 21:00:00','/auth/login','POST',200,1,274.355,274.355),('2026-11-18 21:00:00','/auth/logout','OPTIONS',200,1,0.5953,0.5953),('2026-11-18 21:00:00','/auth/logout','POST',422,1,34.602,34.602),('2026-11-18 21:00:00','/auth/me','GET',200,2,12.2241,7.1734),('2026-11-18 21:00:00','/auth/me','OPTIONS',200,2,1.5349,1.0999),('2026-11-18 21:00:00','/auth/refresh','OPTIONS',200,1,1.3369,1.3369),('2026-11-18 21:00:00','/auth/refresh','POST',401,1,9.5389,9.5389),('2026-11-18 21:00:00','/backoffice/configuracion','GET',307,1,0.9409,0.9409),('2026-11-18 21:00:00','/backoffice/configuracion','OPTIONS',200,1,0.4822,0.4822),('2026-11-18 21:00:00','/backoffice/configuracion/','GET',200,1,13.9401,13.9401),('2026-11-18 21:00:00','/backoffice/configuracion/','OPTIONS',200,1,0.4519,0.4519),('2026-11-18 21:00:00','/backoffice/dashboard','GET',200,1,80.9781,80.9781),('2026-11-18 21:00:00','/backoffice/dashboard','GET',500,6,310.561,113.722),('2026-11-18 21:00:00','/backoffice/dashboard','OPTIONS',200,2,3.6288,2.0006),('2026-11-18 21:00:00','/backoffice/dashboard/infraestructura','GET',200,4,224.677,62.8273),('2026-11-18 21:00:00','/backoffice/dashboard/infraestructura','OPTIONS',200,3,6.5792,2.4303),('2026-11-18 21:00:00','/backoffice/dashboard/serie','GET',200,4,234.51,103.68),('2026-11-18 21:00:00','/backoffice/dashboard/serie','OPTIONS',200,3,11.6503,5.5592),('2026-11-18 21:00:00','/backoffice/errores','GET',307,2,2.7198,1.6974),('2026-11-18 21:00:00','/backoffice/errores','OPTIONS',200,2,1.5887,1.105),('2026-11-18 21:00:00','/backoffice/errores/','GET',200,2,33.5212,17.0275),('2026-11-18 21:00:00','/backoffice/errores/','OPTIONS',200,2,1.7418,1.0995),('2026-11-18 21:00:00','/backoffice/errores/{id}','GET',200,1,17.6978,17.6978),('2026-11-18 21:00:00','/backoffice/errores/{id}','OPTIONS',200,1,1.5216,1.5216),('2026-11-18 21:00:00','/backoffice/procesos','GET',307,1,4.9409,4.9409),('2026-11-18 21:00:00','/backoffice/procesos','OPTIONS',200,1,1.0948,1.0948),('2026-11-18 21:00:00','/backoffice/procesos/','GET',200,1,61.9009,61.9009),('2026-11-18 21:00:00','/backoffice/procesos/','OPTIONS',200,1,1.4042,1.4042),('2026-11-18 21:00:00','/backoffice/procesos/ejecuciones','GET',200,1,72.0807,72.0807),('2026-11-18 21:00:00','/backoffice/procesos/ejecuciones','OPTIONS',200,1,1.0012,1.0012),('2026-11-18 21:00:00','/backoffice/respaldos','GET',307,1,1.165,1.165),('2026-11-18 21:00:00','/backoffice/respaldos','OPTIONS',200,1,2.3214,2.3214),('2026-11-18 21:00:00','/backoffice/respaldos/','GET',200,1,16.5107,16.5107),('2026-11-18 21:00:00','/backoffice/respaldos/','OPTIONS',200,1,1.0855,1.0855),('2026-11-18 21:00:00','/backoffice/seguridad/auditoria','GET',200,1,48.7271,48.7271),('2026-11-18 21:00:00','/backoffice/seguridad/auditoria','OPTIONS',200,1,2.6534,2.6534),('2026-11-18 21:00:00','/backoffice/seguridad/eventos','GET',200,1,38.4608,38.4608),('2026-11-18 21:00:00','/backoffice/seguridad/eventos','OPTIONS',200,1,2.3465,2.3465),('2026-11-18 21:00:00','/backoffice/usuarios','GET',307,4,14.2033,7.7192),('2026-11-18 21:00:00','/backoffice/usuarios','OPTIONS',200,3,2.8954,1.0193),('2026-11-18 21:00:00','/backoffice/usuarios/','GET',200,4,124.691,38.086),('2026-11-18 21:00:00','/backoffice/usuarios/','OPTIONS',200,3,4.7393,3.021),('2026-11-18 21:00:00','/capital','GET',307,1,1.6633,1.6633),('2026-11-18 21:00:00','/capital','OPTIONS',200,1,2.5583,2.5583),('2026-11-18 21:00:00','/capital/','GET',200,1,36.5289,36.5289),('2026-11-18 21:00:00','/capital/','OPTIONS',200,1,2.5528,2.5528),('2026-11-18 21:00:00','/clientes','GET',307,1,2.4623,2.4623),('2026-11-18 21:00:00','/clientes','OPTIONS',200,1,1.1268,1.1268),('2026-11-18 21:00:00','/clientes/','GET',200,1,44.7364,44.7364),('2026-11-18 21:00:00','/clientes/','OPTIONS',200,1,1.5636,1.5636),('2026-11-18 21:00:00','/dashboard/resumen','GET',200,2,161.132,93.0039),('2026-11-18 21:00:00','/dashboard/resumen','OPTIONS',200,2,8.9849,8.5129),('2026-11-18 21:00:00','/notificacion/no-leidas','GET',200,20,405.529,60.017),('2026-11-18 21:00:00','/notificacion/no-leidas','GET',401,1,5.5488,5.5488),('2026-11-18 21:00:00','/notificacion/no-leidas','OPTIONS',200,3,6.6918,3.6707),('2026-11-18 21:00:00','/onboarding/estado','GET',200,3,114.226,61.7274),('2026-11-18 21:00:00','/onboarding/estado','OPTIONS',200,2,5.1695,3.4755),('2026-11-18 21:00:00','/prestamos/','GET',200,2,34.9214,22.6786),('2026-11-18 21:00:00','/prestamos/','OPTIONS',200,1,1.9632,1.9632),('2026-11-18 21:00:00','/tipo_prestamo','GET',307,1,2.2359,2.2359),('2026-11-18 21:00:00','/tipo_prestamo','OPTIONS',200,1,2.3513,2.3513),('2026-11-18 21:00:00','/tipo_prestamo/','GET',200,1,46.9138,46.9138),('2026-11-18 21:00:00','/tipo_prestamo/','OPTIONS',200,1,2.9047,2.9047),('2026-11-18 22:00:00','/auth/me','GET',200,5,43.5824,19.5664),('2026-11-18 22:00:00','/auth/me','OPTIONS',200,1,0.7041,0.7041),('2026-11-18 22:00:00','/backoffice/errores','GET',307,8,40.4937,27.9659),('2026-11-18 22:00:00','/backoffice/errores','OPTIONS',200,1,3.4205,3.4205),('2026-11-18 22:00:00','/backoffice/errores/','GET',200,7,226.796,98.9022),('2026-11-18 22:00:00','/backoffice/errores/','OPTIONS',200,1,1.3615,1.3615),('2026-11-18 22:00:00','/backoffice/errores/{id}','GET',200,2,40.4378,25.6185),('2026-11-18 22:00:00','/backoffice/errores/{id}','OPTIONS',200,1,1.5026,1.5026),('2026-11-18 22:00:00','/backoffice/usuarios','GET',307,1,9.8885,9.8885),('2026-11-18 22:00:00','/backoffice/usuarios/','GET',200,1,94.0528,94.0528),('2026-11-18 22:00:00','/backoffice/usuarios/{id}','GET',500,2,143.843,85.3355),('2026-11-18 22:00:00','/backoffice/usuarios/{id}','OPTIONS',200,1,1.1432,1.1432);
/*!40000 ALTER TABLE `metricas_api` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moras`
--

DROP TABLE IF EXISTS `moras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prestamo_id` int(11) DEFAULT NULL,
  `cuota_id` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `valor` float DEFAULT NULL,
  `estado` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prestamo_id` (`prestamo_id`),
  KEY `cuota_id` (`cuota_id`),
  KEY `ix_moras_id` (`id`),
  CONSTRAINT `moras_ibfk_1` FOREIGN KEY (`prestamo_id`) REFERENCES `prestamos` (`id`),
  CONSTRAINT `moras_ibfk_2` FOREIGN KEY (`cuota_id`) REFERENCES `prestamo_cuotas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moras`
--

LOCK TABLES `moras` WRITE;
/*!40000 ALTER TABLE `moras` DISABLE KEYS */;
INSERT INTO `moras` VALUES (1,1,2,'2026-11-10',102000,'generada','2026-10-08 22:54:09',1),(2,1,1,'2026-10-12',1916.67,'generada','2026-10-12 21:57:56',1),(3,3,13,'2026-11-10',33000,'generada','2026-11-09 17:33:16',1),(4,5,23,'2026-11-10',18000,'generada','2026-11-09 17:33:17',1);
/*!40000 ALTER TABLE `moras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movimientos_capital`
--

DROP TABLE IF EXISTS `movimientos_capital`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movimientos_capital` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_movimiento` enum('inversion','retiro','prestamo_otorgado','pago_recibido','ajuste_prestamo','devolucion_pago','perdida') DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `valor` float DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `prestamo_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prestamo_id` (`prestamo_id`),
  KEY `ix_movimientos_capital_id` (`id`),
  CONSTRAINT `movimientos_capital_ibfk_1` FOREIGN KEY (`prestamo_id`) REFERENCES `prestamos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimientos_capital`
--

LOCK TABLES `movimientos_capital` WRITE;
/*!40000 ALTER TABLE `movimientos_capital` DISABLE KEYS */;
INSERT INTO `movimientos_capital` VALUES (1,'inversion','Capital inicial de prueba',10000000,'2026-09-17',NULL,'2026-09-17 16:15:06',1),(2,'prestamo_otorgado','Préstamo #1 al cliente Carlos Rodríguez',1000000,'2026-09-21',1,'2026-09-21 15:16:08',1),(3,'inversion','Capital inicial',5555560,'2026-10-08',NULL,'2026-10-08 22:12:56',1),(4,'prestamo_otorgado','Préstamo #2 al cliente Camilo',1000000,'2026-10-08',2,'2026-10-08 22:24:18',1),(5,'pago_recibido','Pago cuota #1 (Recibo: REC-20261008-A99E4D) - Préstamo #2',166667,'2026-10-08',2,'2026-10-08 22:26:46',1),(6,'pago_recibido','Pago cuota #2 (Recibo: REC-20261008-D41496) - Préstamo #2',166667,'2026-10-08',2,'2026-10-08 22:29:15',1),(7,'prestamo_otorgado','Préstamo #3 al cliente Andres Jaramillo',1200000,'2026-10-12',3,'2026-10-12 22:29:39',1),(8,'prestamo_otorgado','Préstamo #4 al cliente camiloP',100000,'2026-10-30',4,'2026-10-30 16:39:14',1),(9,'prestamo_otorgado','Préstamo #5 al cliente Andres Jaramillo',120000,'2026-10-30',5,'2026-10-30 16:40:14',1),(10,'pago_recibido','Pago cuota #1 (Recibo: REC-20261102-D27323) - Préstamo #1',166667,'2026-11-02',1,'2026-11-02 23:30:08',1),(11,'inversion','Primer registro',100000,'2026-11-09',NULL,'2026-11-09 20:38:32',3),(12,'inversion','Capital inicial',1000000,'2026-11-09',NULL,'2026-11-09 20:54:16',3),(13,'prestamo_otorgado','Préstamo #6 al cliente camiloP',100000,'2026-11-09',6,'2026-11-09 21:39:02',1),(14,'inversion','Capital inicial',2000000,'2026-11-18',NULL,'2026-11-18 16:36:04',2),(15,'prestamo_otorgado','Préstamo #7 al cliente Prueba de fuego',1000000,'2026-11-18',7,'2026-11-18 16:42:05',2),(16,'pago_recibido','Pago cuota #1 (Recibo: REC-20261118-5D9BC9) - Préstamo #7',0,'2026-11-18',7,'2026-11-18 16:43:39',2);
/*!40000 ALTER TABLE `movimientos_capital` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notificaciones`
--

DROP TABLE IF EXISTS `notificaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notificaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `titulo` varchar(150) NOT NULL,
  `mensaje` text NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `leida` tinyint(1) DEFAULT NULL,
  `push_enviado` tinyint(1) DEFAULT NULL,
  `fecha` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `ix_notificaciones_id` (`id`),
  CONSTRAINT `notificaciones_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificaciones`
--

LOCK TABLES `notificaciones` WRITE;
/*!40000 ALTER TABLE `notificaciones` DISABLE KEYS */;
INSERT INTO `notificaciones` VALUES (1,1,'Nueva solicitud pública #1','Andres Jaramillo solicitó $1,200,000 a 6 cuotas desde la página web.','/solicitudes/1','solicitud',0,0,'2026-10-12 22:23:49');
/*!40000 ALTER TABLE `notificaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos`
--

DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pagos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prestamo_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `cuota_id` int(11) DEFAULT NULL,
  `tipo_pago_id` int(11) DEFAULT NULL,
  `fecha_pago` date DEFAULT NULL,
  `valor_pagado` float DEFAULT NULL,
  `capital_pagado` float DEFAULT NULL,
  `interes_pagado` float DEFAULT NULL,
  `mora_pagada` float DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `referencia_recibo` varchar(50) NOT NULL,
  `estado_pago` enum('confirmado','devuelto') DEFAULT NULL,
  `fecha_devolucion` datetime DEFAULT NULL,
  `motivo_devolucion` text DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prestamo_id` (`prestamo_id`),
  KEY `cliente_id` (`cliente_id`),
  KEY `cuota_id` (`cuota_id`),
  KEY `tipo_pago_id` (`tipo_pago_id`),
  KEY `ix_pagos_id` (`id`),
  CONSTRAINT `pagos_ibfk_1` FOREIGN KEY (`prestamo_id`) REFERENCES `prestamos` (`id`),
  CONSTRAINT `pagos_ibfk_2` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`),
  CONSTRAINT `pagos_ibfk_3` FOREIGN KEY (`cuota_id`) REFERENCES `prestamo_cuotas` (`id`),
  CONSTRAINT `pagos_ibfk_4` FOREIGN KEY (`tipo_pago_id`) REFERENCES `tipos_pago` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos`
--

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
INSERT INTO `pagos` VALUES (1,2,2,7,1,'2026-10-08',191667,166667,25000,0,NULL,'2026-10-08 22:26:46','2026-10-08 22:26:46','REC-20261008-A99E4D','confirmado',NULL,NULL,1),(2,2,2,8,1,'2026-10-08',191667,166667,25000,0,NULL,'2026-10-08 22:29:15','2026-10-08 22:29:15','REC-20261008-D41496','confirmado',NULL,NULL,1),(3,1,1,1,1,'2026-11-02',191667,166667,25000,0,NULL,'2026-11-02 23:30:08','2026-11-02 23:30:08','REC-20261102-D27323','confirmado',NULL,NULL,1),(4,7,8,31,4,'2026-11-18',30000,0,30000,0,NULL,'2026-11-18 16:43:39','2026-11-18 16:43:39','REC-20261118-5D9BC9','confirmado',NULL,NULL,2);
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plantillas_mensaje`
--

DROP TABLE IF EXISTS `plantillas_mensaje`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plantillas_mensaje` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clave` varchar(80) NOT NULL,
  `canal` enum('email','sms','whatsapp') DEFAULT NULL,
  `nombre` varchar(120) NOT NULL,
  `asunto` varchar(200) DEFAULT NULL,
  `cuerpo` text NOT NULL,
  `activa` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_plantillas_usuario_clave` (`usuario_id`,`clave`,`canal`),
  KEY `ix_plantillas_mensaje_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plantillas_mensaje`
--

LOCK TABLES `plantillas_mensaje` WRITE;
/*!40000 ALTER TABLE `plantillas_mensaje` DISABLE KEYS */;
INSERT INTO `plantillas_mensaje` VALUES (1,'solicitud_pago','whatsapp','Aviso',NULL,'Hola {{nombre}} recuerda pagar',1,'2026-10-09 00:04:00','2026-10-09 00:04:00',1),(2,'solicitud_pago_correo','email','Aviso Correo','Recuerda pagar','Tu cuota sta proxima a vencer recuerda pagar',1,'2026-11-09 17:38:24','2026-11-09 17:38:24',1);
/*!40000 ALTER TABLE `plantillas_mensaje` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestamo_cuotas`
--

DROP TABLE IF EXISTS `prestamo_cuotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prestamo_cuotas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prestamo_id` int(11) DEFAULT NULL,
  `numero_cuota` int(11) DEFAULT NULL,
  `fecha_vencimiento` date DEFAULT NULL,
  `valor_cuota` float DEFAULT NULL,
  `monto_interes` float DEFAULT NULL,
  `capital` float DEFAULT NULL,
  `interes` float DEFAULT NULL,
  `mora` float DEFAULT NULL,
  `estado` enum('pendiente','pagado','vencido','parcial') DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `referencia_pago` varchar(50) DEFAULT NULL,
  `fecha_pago` date DEFAULT NULL,
  `reestructuracion_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prestamo_id` (`prestamo_id`),
  KEY `ix_prestamo_cuotas_id` (`id`),
  CONSTRAINT `prestamo_cuotas_ibfk_1` FOREIGN KEY (`prestamo_id`) REFERENCES `prestamos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestamo_cuotas`
--

LOCK TABLES `prestamo_cuotas` WRITE;
/*!40000 ALTER TABLE `prestamo_cuotas` DISABLE KEYS */;
INSERT INTO `prestamo_cuotas` VALUES (1,1,1,'2026-10-08',191667,25000,166667,25000,0,'pagado','2026-09-21 15:16:08','2026-11-02 23:30:08',NULL,NULL,NULL),(2,1,2,'2026-10-04',191667,25000,166667,25000,0,'vencido','2026-09-21 15:16:08','2026-10-08 22:54:09',NULL,NULL,NULL),(3,1,3,'2026-12-21',191667,25000,166667,25000,0,'pendiente','2026-09-21 15:16:08','2026-09-21 15:16:08',NULL,NULL,NULL),(4,1,4,'2027-01-21',191667,25000,166667,25000,0,'pendiente','2026-09-21 15:16:08','2026-09-21 15:16:08',NULL,NULL,NULL),(5,1,5,'2027-02-21',191667,25000,166667,25000,0,'pendiente','2026-09-21 15:16:08','2026-09-21 15:16:08',NULL,NULL,NULL),(6,1,6,'2027-03-21',191667,25000,166667,25000,0,'pendiente','2026-09-21 15:16:08','2026-09-21 15:16:08',NULL,NULL,NULL),(7,2,1,'2026-11-08',191667,25000,166667,25000,0,'pagado','2026-10-08 22:24:18','2026-10-08 22:26:46','REF-P2C1-TBUD',NULL,NULL),(8,2,2,'2026-12-08',191667,25000,166667,25000,0,'pagado','2026-10-08 22:24:18','2026-10-08 22:29:15','REF-P2C2-D6UC',NULL,NULL),(9,2,3,'2027-01-08',191667,25000,166667,25000,0,'pendiente','2026-10-08 22:24:18','2026-10-08 22:24:18','REF-P2C3-7MWV',NULL,NULL),(10,2,4,'2027-02-08',191667,25000,166667,25000,0,'pendiente','2026-10-08 22:24:18','2026-10-08 22:24:18','REF-P2C4-G98H',NULL,NULL),(11,2,5,'2027-03-08',191667,25000,166667,25000,0,'pendiente','2026-10-08 22:24:18','2026-10-08 22:24:18','REF-P2C5-AR2D',NULL,NULL),(12,2,6,'2027-04-08',191667,25000,166667,25000,0,'pendiente','2026-10-08 22:24:18','2026-10-08 22:24:18','REF-P2C6-Y4QN',NULL,NULL),(13,3,1,'2026-10-27',230000,30000,200000,30000,0,'vencido','2026-10-12 22:29:39','2026-11-09 17:33:16','REF-P3C1-PN8I',NULL,NULL),(14,3,2,'2026-11-11',230000,30000,200000,30000,0,'pendiente','2026-10-12 22:29:39','2026-10-12 22:29:39','REF-P3C2-XJZI',NULL,NULL),(15,3,3,'2026-11-26',230000,30000,200000,30000,0,'pendiente','2026-10-12 22:29:40','2026-10-12 22:29:40','REF-P3C3-LZTQ',NULL,NULL),(16,3,4,'2026-12-11',230000,30000,200000,30000,0,'pendiente','2026-10-12 22:29:40','2026-10-12 22:29:40','REF-P3C4-T4D5',NULL,NULL),(17,3,5,'2026-12-26',230000,30000,200000,30000,0,'pendiente','2026-10-12 22:29:40','2026-10-12 22:29:40','REF-P3C5-L7H6',NULL,NULL),(18,3,6,'2027-01-10',230000,30000,200000,30000,0,'pendiente','2026-10-12 22:29:40','2026-10-12 22:29:40','REF-P3C6-XMRN',NULL,NULL),(19,4,1,'2026-11-30',27500,2500,25000,2500,0,'pendiente','2026-10-30 16:39:14','2026-10-30 16:39:14','REF-P4C1-COK0',NULL,NULL),(20,4,2,'2026-12-30',27500,2500,25000,2500,0,'pendiente','2026-10-30 16:39:14','2026-10-30 16:39:14','REF-P4C2-TO5D',NULL,NULL),(21,4,3,'2027-01-30',27500,2500,25000,2500,0,'pendiente','2026-10-30 16:39:14','2026-10-30 16:39:14','REF-P4C3-QF94',NULL,NULL),(22,4,4,'2027-02-28',27500,2500,25000,2500,0,'pendiente','2026-10-30 16:39:14','2026-10-30 16:39:14','REF-P4C4-AD8R',NULL,NULL),(23,5,1,'2026-11-01',33000,3000,30000,3000,0,'vencido','2026-10-30 16:40:14','2026-11-09 17:33:17','REF-P5C1-EUZK',NULL,NULL),(24,5,2,'2026-12-01',33000,3000,30000,3000,0,'pendiente','2026-10-30 16:40:14','2026-10-30 16:40:14','REF-P5C2-6VPL',NULL,NULL),(25,5,3,'2027-01-01',33000,3000,30000,3000,0,'pendiente','2026-10-30 16:40:14','2026-10-30 16:40:14','REF-P5C3-DQCH',NULL,NULL),(26,5,4,'2027-02-01',33000,3000,30000,3000,0,'pendiente','2026-10-30 16:40:14','2026-10-30 16:40:14','REF-P5C4-66IG',NULL,NULL),(27,6,1,'2026-11-24',26250,1250,25000,1250,0,'pendiente','2026-11-09 21:39:02','2026-11-09 21:39:02','REF-P6C1-3C9E',NULL,NULL),(28,6,2,'2026-12-09',26250,1250,25000,1250,0,'pendiente','2026-11-09 21:39:02','2026-11-09 21:39:02','REF-P6C2-1ENS',NULL,NULL),(29,6,3,'2026-12-24',26250,1250,25000,1250,0,'pendiente','2026-11-09 21:39:02','2026-11-09 21:39:02','REF-P6C3-HGVI',NULL,NULL),(30,6,4,'2027-01-08',26250,1250,25000,1250,0,'pendiente','2026-11-09 21:39:02','2026-11-09 21:39:02','REF-P6C4-KZS1',NULL,NULL),(31,7,1,'2026-12-18',196667,30000,166667,30000,0,'parcial','2026-11-18 16:42:05','2026-11-18 16:43:39','REF-P7C1-VB3M',NULL,NULL),(32,7,2,'2027-01-18',196667,30000,166667,30000,0,'pendiente','2026-11-18 16:42:05','2026-11-18 16:42:05','REF-P7C2-PS3J',NULL,NULL),(33,7,3,'2027-02-18',196667,30000,166667,30000,0,'pendiente','2026-11-18 16:42:05','2026-11-18 16:42:05','REF-P7C3-TLT7',NULL,NULL),(34,7,4,'2027-03-18',196667,30000,166667,30000,0,'pendiente','2026-11-18 16:42:05','2026-11-18 16:42:05','REF-P7C4-8MJN',NULL,NULL),(35,7,5,'2027-04-18',196667,30000,166667,30000,0,'pendiente','2026-11-18 16:42:05','2026-11-18 16:42:05','REF-P7C5-LKGX',NULL,NULL),(36,7,6,'2027-05-18',196667,30000,166667,30000,0,'pendiente','2026-11-18 16:42:05','2026-11-18 16:42:05','REF-P7C6-PF2D',NULL,NULL);
/*!40000 ALTER TABLE `prestamo_cuotas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestamos`
--

DROP TABLE IF EXISTS `prestamos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prestamos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) DEFAULT NULL,
  `tipo_prestamo_id` int(11) DEFAULT NULL,
  `fecha_prestamo` date DEFAULT NULL,
  `capital_prestado` float DEFAULT NULL,
  `porcentaje_interes` float DEFAULT NULL,
  `interes_total` float DEFAULT NULL,
  `monto_total` float DEFAULT NULL,
  `numero_cuotas` int(11) DEFAULT NULL,
  `valor_cuota` float DEFAULT NULL,
  `saldo_pendiente` float DEFAULT NULL,
  `estado` enum('activo','pagado','perdido','renovado') DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cliente_id` (`cliente_id`),
  KEY `tipo_prestamo_id` (`tipo_prestamo_id`),
  KEY `ix_prestamos_id` (`id`),
  CONSTRAINT `prestamos_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`),
  CONSTRAINT `prestamos_ibfk_2` FOREIGN KEY (`tipo_prestamo_id`) REFERENCES `tipos_prestamo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestamos`
--

LOCK TABLES `prestamos` WRITE;
/*!40000 ALTER TABLE `prestamos` DISABLE KEYS */;
INSERT INTO `prestamos` VALUES (1,1,1,'2026-09-21',1000000,2.5,150000,1150000,6,191667,958333,'activo',NULL,'2026-09-21 15:16:08','2026-11-02 23:30:08',1),(2,2,1,'2026-10-08',1000000,2.5,150000,1150000,6,191667,766666,'activo',NULL,'2026-10-08 22:24:18','2026-10-08 22:29:15',1),(3,3,5,'2026-10-12',1200000,2.5,180000,1380000,6,230000,1380000,'activo',NULL,'2026-10-12 22:29:39','2026-10-12 22:29:39',1),(4,4,1,'2026-10-30',100000,2.5,10000,110000,4,27500,110000,'activo',NULL,'2026-10-30 16:39:14','2026-10-30 16:39:14',1),(5,3,1,'2026-10-01',120000,2.5,12000,132000,4,33000,132000,'activo',NULL,'2026-10-30 16:40:14','2026-10-30 16:40:14',1),(6,4,5,'2026-11-09',100000,2.5,5000,105000,4,26250,105000,'activo',NULL,'2026-11-09 21:39:02','2026-11-09 21:39:02',1),(7,8,9,'2026-11-18',1000000,3,180000,1180000,6,196667,1150000,'activo',NULL,'2026-11-18 16:42:05','2026-11-18 16:43:39',2);
/*!40000 ALTER TABLE `prestamos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestamos_perdidos`
--

DROP TABLE IF EXISTS `prestamos_perdidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prestamos_perdidos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prestamo_id` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `valor_perdido` float DEFAULT NULL,
  `motivo` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prestamo_id` (`prestamo_id`),
  KEY `ix_prestamos_perdidos_id` (`id`),
  CONSTRAINT `prestamos_perdidos_ibfk_1` FOREIGN KEY (`prestamo_id`) REFERENCES `prestamos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestamos_perdidos`
--

LOCK TABLES `prestamos_perdidos` WRITE;
/*!40000 ALTER TABLE `prestamos_perdidos` DISABLE KEYS */;
/*!40000 ALTER TABLE `prestamos_perdidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestamos_reestructuraciones`
--

DROP TABLE IF EXISTS `prestamos_reestructuraciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prestamos_reestructuraciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prestamo_id` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `motivo` text DEFAULT NULL,
  `saldo_anterior` float DEFAULT NULL,
  `numero_cuotas` int(11) DEFAULT NULL,
  `porcentaje_interes` float DEFAULT NULL,
  `valor_cuota` float DEFAULT NULL,
  `monto_plan` float DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prestamo_id` (`prestamo_id`),
  KEY `ix_prestamos_reestructuraciones_id` (`id`),
  CONSTRAINT `prestamos_reestructuraciones_ibfk_1` FOREIGN KEY (`prestamo_id`) REFERENCES `prestamos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestamos_reestructuraciones`
--

LOCK TABLES `prestamos_reestructuraciones` WRITE;
/*!40000 ALTER TABLE `prestamos_reestructuraciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `prestamos_reestructuraciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prestamos_renovaciones`
--

DROP TABLE IF EXISTS `prestamos_renovaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prestamos_renovaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prestamo_anterior_id` int(11) DEFAULT NULL,
  `prestamo_nuevo_id` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prestamo_anterior_id` (`prestamo_anterior_id`),
  KEY `prestamo_nuevo_id` (`prestamo_nuevo_id`),
  KEY `ix_prestamos_renovaciones_id` (`id`),
  CONSTRAINT `prestamos_renovaciones_ibfk_1` FOREIGN KEY (`prestamo_anterior_id`) REFERENCES `prestamos` (`id`),
  CONSTRAINT `prestamos_renovaciones_ibfk_2` FOREIGN KEY (`prestamo_nuevo_id`) REFERENCES `prestamos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prestamos_renovaciones`
--

LOCK TABLES `prestamos_renovaciones` WRITE;
/*!40000 ALTER TABLE `prestamos_renovaciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `prestamos_renovaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `push_subscriptions`
--

DROP TABLE IF EXISTS `push_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `endpoint` text NOT NULL,
  `p256dh` varchar(255) NOT NULL,
  `auth` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `endpoint` (`endpoint`) USING HASH,
  KEY `usuario_id` (`usuario_id`),
  KEY `ix_push_subscriptions_id` (`id`),
  CONSTRAINT `push_subscriptions_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `push_subscriptions`
--

LOCK TABLES `push_subscriptions` WRITE;
/*!40000 ALTER TABLE `push_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `push_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solicitudes_prestamo`
--

DROP TABLE IF EXISTS `solicitudes_prestamo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solicitudes_prestamo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_id` int(11) NOT NULL,
  `tipo_prestamo_id` int(11) NOT NULL,
  `monto_solicitado` float NOT NULL,
  `plazo_cuotas` int(11) NOT NULL,
  `porcentaje_interes` float NOT NULL,
  `motivo` text NOT NULL,
  `estado` enum('pendiente','aprobada','rechazada','convertida','expirada') DEFAULT NULL,
  `usuario_creador_id` int(11) DEFAULT NULL,
  `evaluador_id` int(11) DEFAULT NULL,
  `fecha_decision` datetime DEFAULT NULL,
  `motivo_decision` text DEFAULT NULL,
  `fecha_expiracion` date DEFAULT NULL,
  `prestamo_id` int(11) DEFAULT NULL,
  `puntaje_scoring` float DEFAULT NULL,
  `scoring_detalle` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cliente_id` (`cliente_id`),
  KEY `tipo_prestamo_id` (`tipo_prestamo_id`),
  KEY `usuario_creador_id` (`usuario_creador_id`),
  KEY `evaluador_id` (`evaluador_id`),
  KEY `prestamo_id` (`prestamo_id`),
  KEY `ix_solicitudes_prestamo_id` (`id`),
  CONSTRAINT `solicitudes_prestamo_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`),
  CONSTRAINT `solicitudes_prestamo_ibfk_2` FOREIGN KEY (`tipo_prestamo_id`) REFERENCES `tipos_prestamo` (`id`),
  CONSTRAINT `solicitudes_prestamo_ibfk_3` FOREIGN KEY (`usuario_creador_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `solicitudes_prestamo_ibfk_4` FOREIGN KEY (`evaluador_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `solicitudes_prestamo_ibfk_5` FOREIGN KEY (`prestamo_id`) REFERENCES `prestamos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitudes_prestamo`
--

LOCK TABLES `solicitudes_prestamo` WRITE;
/*!40000 ALTER TABLE `solicitudes_prestamo` DISABLE KEYS */;
INSERT INTO `solicitudes_prestamo` VALUES (1,3,5,1200000,6,2.5,'Capital personal','convertida',NULL,1,'2026-10-12 22:27:07','Se aprueba solicitud de prestamo','2026-10-19',3,600,'{\"proveedor\": \"piloto\", \"prestamos_pagados\": 0, \"prestamos_perdidos\": 0, \"prestamos_activos\": 0, \"cuotas_vencidas\": 0, \"moras_activas\": 0}','2026-10-12 22:23:49','2026-10-12 22:29:40');
/*!40000 ALTER TABLE `solicitudes_prestamo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos_cita`
--

DROP TABLE IF EXISTS `tipos_cita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipos_cita` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `color` varchar(20) NOT NULL,
  `duracion_minutos` int(11) NOT NULL,
  `estado` enum('activo','inactivo') DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_tipos_cita_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos_cita`
--

LOCK TABLES `tipos_cita` WRITE;
/*!40000 ALTER TABLE `tipos_cita` DISABLE KEYS */;
INSERT INTO `tipos_cita` VALUES (1,'Recogida de dinero',NULL,'#7c3aed',30,'activo','2026-10-12 21:34:26','2026-10-12 21:34:26',1),(2,'Recogida de dinero',NULL,'#ff0000',30,'activo','2026-11-18 16:45:36','2026-11-18 16:45:36',2);
/*!40000 ALTER TABLE `tipos_cita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos_pago`
--

DROP TABLE IF EXISTS `tipos_pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipos_pago` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `estado` enum('activo','inactivo') DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_tipos_pago_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos_pago`
--

LOCK TABLES `tipos_pago` WRITE;
/*!40000 ALTER TABLE `tipos_pago` DISABLE KEYS */;
INSERT INTO `tipos_pago` VALUES (1,'Efectivo','Tipo de pago predefinido','activo','2026-09-21 15:11:20','2026-09-21 15:11:20',1),(2,'Preuba','prueba de creacion','activo','2026-10-08 22:12:10','2026-10-08 22:21:38',1),(3,'Efectivo','efectivo','activo','2026-11-09 20:53:28','2026-11-09 20:53:28',3),(4,'Efectivo camilo','DEscripcionnn','activo','2026-11-18 16:43:09','2026-11-18 16:43:09',2);
/*!40000 ALTER TABLE `tipos_pago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos_prestamo`
--

DROP TABLE IF EXISTS `tipos_prestamo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipos_prestamo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `interes_mensual` float DEFAULT NULL,
  `max_cuotas` int(11) DEFAULT NULL,
  `estado` enum('activo','inactivo') DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `intervalo_pago` enum('mensual','quincenal','bimestral','personalizado') DEFAULT NULL,
  `intervalo_dias` int(11) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `aplicacion_interes` enum('mensual','por_pago') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_tipos_prestamo_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos_prestamo`
--

LOCK TABLES `tipos_prestamo` WRITE;
/*!40000 ALTER TABLE `tipos_prestamo` DISABLE KEYS */;
INSERT INTO `tipos_prestamo` VALUES (1,'Préstamo Personal','Préstamo para uso personal',2.5,12,'activo','2026-09-17 16:15:06','2026-09-17 16:15:06','mensual',NULL,1,'por_pago'),(2,'Préstamo Empresarial','Préstamo para negocios',2,24,'activo','2026-09-17 16:15:06','2026-09-17 16:15:06','mensual',NULL,1,'por_pago'),(3,'Préstamo de Emergencia','Préstamo rápido para emergencias',3,6,'activo','2026-09-17 16:15:06','2026-09-17 16:15:06','mensual',NULL,1,'por_pago'),(4,'Prueba','tipo de prestamos de prueba',5,6,'activo','2026-10-08 22:11:31','2026-10-08 22:21:10','mensual',NULL,1,'por_pago'),(5,'Quincenal','prestamo de prueba quincenal',2.5,12,'activo','2026-10-12 18:16:51','2026-11-09 21:36:42','quincenal',NULL,1,'mensual'),(6,'CamiloP','prestamo especializado para cliente',3,5,'activo','2026-10-30 16:35:55','2026-10-30 16:35:55','quincenal',NULL,1,'mensual'),(7,'Personal andres','Por defecto',2,12,'activo','2026-11-09 20:47:12','2026-11-09 20:47:12','mensual',NULL,3,'por_pago'),(8,'Pretamo Camilo','Prestamo del 5% de interes maximo 5 millones de capital',5,12,'activo','2026-11-10 20:52:31','2026-11-10 20:52:31','mensual',NULL,2,'por_pago'),(9,'Empresarialll','descripcionnn',3,13,'activo','2026-11-18 16:23:56','2026-11-18 16:23:56','mensual',NULL,2,'por_pago');
/*!40000 ALTER TABLE `tipos_prestamo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `access_token` varchar(500) NOT NULL,
  `refresh_token` varchar(500) NOT NULL,
  `activo` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `ultimo_uso_at` datetime DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_tokens_id` (`id`),
  KEY `idx_tokens_usuario_activo` (`usuario_id`,`activo`),
  KEY `idx_tokens_expires_at` (`expires_at`),
  CONSTRAINT `tokens_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
INSERT INTO `tokens` VALUES (32,2,'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.IZbEz7YK0vAiqiwdN9pq-Am048oSU5QORzPTnKK-TiykrDTeUZycGLPsnKzLdlN4-QAJaXuLy6OZdc5HmmW-5UNrtDIQxRfK.P2rx3sG4I5rCimhT9KEUPg.MOA19duONIS8Zb93EPzF2hI5ZDVNzJ67HSHrrGxbL60q1QowIDYYJTJQBX_jGC0iu2sV8DE-xzk1otrRASZzovzYa9f8ZTNdQqf_I7YP9ReccO5SCBGjc5wgECjhe53H5kM7QRU55BC7taR5zIUiNaN7YvYAnFILvQd9WICaBgry7gIdhF8b6OfjRrCoFPsm3XMZ8X4z6YlGliUKFl8OB5BsPmERRfquqCRzLPBGMeHvn6leXjqXLSPDnVQhDElk.lQ2VPp5klPDNWgBlpoBOLnQfBQFcjhgnZ-YO1lsganQ','eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.J_UtzxDQy5iVfRAttGzHP6wZ_VBSQ5mwqXaVrbSHDAqZ-w0X5eP_tJJYHU41lPD9Ng-ESBLlkCLTwCB-T2X6KbUuzx34CYVo.76drq4sS6crrBlQXmtu9RA.LGmLurc50gpi6I5K5Z1R8Vs2ObxYMfPV0HXv-pimHm11m5BdUpSfaF5oEiV6yeKHZyy2ly0tigI_ffUZL6we2GWPRoRqlM650RNEYduK0nAZRYq3JmMGtlLHo3mqh1cq0U7Zilu7k0MQHMvJ2uN_Q9c02c2aIJHs7zJoK-pouRhYBnGm1XiD8GCC3SA8u4Lppw-OxasFDeui0yegUEQGkK-7Djf3ZLLgLAL7cqkyNlKdl5aLph_sijiybqjrmMARaz8MBEpSA2d3GGWkXvF1oA.6ARSN3_akjmI5DQdxxQw5eln-3pyUbwCqXQfIo4ygWE',1,'2026-10-30 17:30:09','2026-11-06 17:30:09',NULL,NULL,NULL),(36,2,'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.bU3zjoOGUL8haooakEjRdB1KO32agpzdqYaYC8LD55zdHaLfKiMu_hwuCe9dj7QTVx76bvXNjQdH08aK8Pk6440RWiqn-ezO.p0yBhuv7yGYuiR_uZBYkGw.cZV_RASCo060NfOP8K7YgoFirzhbAOYnd1mh4EF63tuQvimAi2wWT7jlaqR8J3fhEzQy8DgEsKzywtLpEB0agu5hH_8C985vPpLYKZlGrheFe6E8iQyCiUCQNojmWGZG9nUNHFRPi_dHwQX3q_JA21kb_wyWdwGcCt9_5ypllkPBaXdxI1iqrMIUSJgDqkeeKEuc0oiGPOuxqlHHnWYxacCKEL3DgvBCyQLCA4V7wu3MV5QZdysxvWefXuXkyemg.05f1vQWrTyHHZv3e_JFLJRk0wrHJ6fqYS2EumoLZKwg','eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.EYm3fRkcTbRpSaDWSCAqTRofYqwalxOCb4-My2DPAvcMApKHUYB3coEbpqOsDr38vr3uaenPlxoNEkWEFwdSNgToyCTBSPRJ.80V6gSnAvBbdksIFfQwz4Q.yvhur3HLatJYpAnNMLHB7pRFht2DIprpSwlXJzNz8Y2-49noQNCbqdS6dIEQF7zjBip838iZqGG055yceyLjPSS0jerWDEUwPOb5gnX8ndWdPyS_G1kLotEcKZBQTwSiWbo4hFpDk8aBXEGlU_fcVrwgaErIBn_Qz2KcNBgNbhvsg_XUgSSubvUUFbIn48om1f7TvskicI9OtoIbGaVf4I-gKt7ICDBfcw4B2QwpRTtH1KQrfU2PqNU9M4elhJNyWFgFA2rqXouF5Jrgnq294Q.7hgIPgdGbjUgZ09rGlaF0dWdrNNqnMNTvQujD5nP7hY',1,'2026-11-09 16:51:51','2026-11-16 16:51:51',NULL,NULL,NULL),(37,2,'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.2Zcqi_qI9AvBcKhKNZdsYOSi-RMpapJyYD3z2C0LElKnRnFc51sPVADLWvuGfnjk8pvc0d_3s9peyhL5UdKv21hQxfDg4OtA.Y3wRlMunlPR5LlD5-TA4rA.AIHZkcOKgw6RuBxVAIeFfJR4rrZ3U2X4-0dauFpEue8MFwTpZnDG2NQfJKJ9YYYbIN2RWU6sp3akArT-KJujy1hfVckN_c9Isv719vnl0YDB8zlwAeCF2ccC2krTBk4jA0cYTs7GWDB6ROCrttZ7E8rvdMMM5QVNyNTJU4x4E-X3o9CPncYoEd8ggHtRyojEQhlG4a8LztnErQkdxGTO-cVdEt6CraJ3D07UMSwYDkZELsxZINL1e4TrRD-ZtnIs.c1OOluoHV85PbusCISEoaQ7LVOH-Aw4vg-EAoxQ_3pY','eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.QXejSZf2O98lgkOuHYuVICy53LGq0brlIJ0LrAouOidPolK0114tnV4sGKThv6jMruN98H-inldAP2qAJxyuO_FKQCjGCvid.2vHW2lCtwtE5vbTpBWFPkw.AgcRbO4dtM8xYvMqc_uvA6oUGJEy4AleAVhUe_nyQTcLvQR0sWnrVT_4YgZ9l2nV1JBbNt8wsFeVamuDQpyHnUi5c5ZiPaLqgKM9ZBdHyohAh6G160oG78TLFCvM8fx6NsKDpFKmhCCMdSINSBOAm2bcUIeIA812rbVlM8ddxsgNhhTcsGlb2rF77ONEsZr_DYJA6VC0I-40XTNNfTYzMSTPeQvgHPefrhRAW29-KiEEWkGZOPuGM603v3_SS7sdrhwASIx2vEk2iQxXsTqciw.W_5iccZ5i0SF9S59bKnUZ8IujPfgFE5OSPL3j_gMKrY',1,'2026-11-09 16:54:30','2026-11-16 16:54:30',NULL,NULL,NULL),(38,2,'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.JKnaXNroEbn7EHnRYyfsrzJGBowI6czvDCsbtNuuHf4_In7Fb5CGNsu7Cw34bar_SY-6uf64XTpCWhGOI3Kg9cqez4Ri1zmr.W2K_ziSVi7mYpPeTIIl8Fw.GRcMNaVDsoHypv09chSQeztAcWCqgKZPUaIi5lx8wQhrDVafRfmukyKlCvZf-BKmmMq8xOIIY0BfKlXl1vWpMCkzxurELtoRxz1wLylO42vmpx4799Y9SsXXv9IW9zz0D4fqaRAAQBBn_l04X5joraiFdVglKsucAJauKeIjy4r2BQEvhyEBDeKzKXqKzv7SJPQV2qAeXvxCB4WYWj93xMTwcqWynWvkDG1j1r86EapO4Xw5CCbC5orYhRNTlRWZ.OeZ_CP1YMwbknqBE9bHkZdITmvMlZnNgsDxT8YTt4YE','eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.lrWhZwEjuRa8FOszViQuO7Cvgpq_s2GzGJyqdvkK5g4EogE460LmhMVfryokFVi4GUMkllsyE5gHxkQ7X6OZxBjJ6kWT4zyW.n-rDn6envneAb6_UPg9gfw.HPEpPeZzPVHdPYCA_vq0Th63c7X2uqxDISscrsHWz_ehiFi2e27WQg_itS1MCNUWERx0AXRRcMwjjn5lQGRWeHdA9gNslS_gOuzqx33SQ79TJk69uk3owSQjLw-rPiP3smGvgGKSXTkM1BGjUyUxBtgsETsUn03lsZcKGcNCx0WGKDvy4mmgGEcYi2LUsZIQIBdvBypNldAoolgI37JIz3aeqaSf2ZGkjhz7TyVflLGYylVN-zAs89MteFFubatD75ExhRLgdyEcoc-Gte0D9w.S1nLA1N4gw6I0qp9NwoRGvKP1znvJRQ6weaDgz5OKiU',1,'2026-11-09 16:55:23','2026-11-16 16:55:23',NULL,NULL,NULL),(39,2,'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.UgwPGdUEc_-2N4mHLyY018h3YZSNYD1eX_rfVhl2xh8HbWEnuz7NCX4rMTEt4KZ6ru7kmDz7qj6VipL3lrH-8oAYLmcO5plp.rVWJfh2_BmqrJxAIML5qzg.cgC_oVROlLsYy39iobetNIFWUdjv77YRewCMV9LMgIU8rbdlnOgoIWFEzLKOGHJkPqf-GPTTvmMpYEwnh3vVLHok1FLQNYkGPD-M83Kr8liNFxeE0ySM33nvejURfDlZleVu6TX6Alhf_r2CInZDVarviARF98jKw6GnpnHWdNV937XWK7SKQwb0MeAsjqmfDnCBeM9UQOJ5TMak03FpPH9dS7hnakvdYyyawvaIfGls0T1Bi0Hr9K8AL99gzzco.76MGFwjaUphuP-QbTpe7sQXu0eRgMnPpm-zHe0HnUPE','eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.XncoEOWhHA3usf8BreUCJX9rCtJBwDdVji0TTyA8B90jNwPgi-hibZzVzNpUxQKiUrCUGyzqrykuiF10vnl82JbclShDYD6C.-CRIPv4jC5SVAMik9kGNfA.qTTt9EeAllc4pQRJ7ytxdNd7jPx_Tnu-2EUbOL9k0jHJxxfHg3hYP51evE1nKxrIPw18qXjd3E2Rbq3rOCr-ylnnFOajFEeow8T9P5UXMqHdzdV8_Cnu4Ed7CT5dVTFiSE7hRXzrdNUXLwIixITM5Gr04a0ABAJmTTxl5WuwZVRe_EC0Py83G67wTlDV0FXgbv9E3wIDIkFDZIMsCEydY-lgz19nz3tUIBU55OCRx2xpnjxvZrbJ4givrKpvJTcxtzvA5PNRAi0KRGj98Li-3g.2H60ElAbCilx77HlT7O9kcuzM2FihQBzm9Xnk3wS8zg',1,'2026-11-09 17:00:49','2026-11-16 17:00:49',NULL,NULL,NULL),(41,3,'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.cxjG9dTDiaLn5EBT6Oe1Uiys3G-7etxVGwA4YNONMkcdPZ4G7O3X1GCXCjoWOEAohHZ9-b-sykkPfTSt2ZFjfw112m7yDHwJ.7XsL8cFtc5y3eDQSc8rjuA.g6suzSEE_EXvMGd8jB6xipoLPoHEFwRCGApJbaauQ5y8v7KBUkHo9gT_Aq4kl9Pf1Hpl9rhS6xx7gFgcA3-AD618pwRFBtpj0JZdt9kuBuPbIzsZfmEHJ-3Y8npmP4O3QTfo_ZCy5clqVOA85U-892Ln7ePQCfRoLpxyZiorBNCAK7MlsscG2whya-d6LfOOnSdv2LtqprF2mPmniITnJT7utZpDMu9GIvOTSNRMlxc.GfN1SuVVwog2Br2KyvOop5AoUFZkeN65SXfLM54hA1Q','eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.L8MpgMAYuoIAVUPtKSENe2jplfsmO86JxNdY36d3e2lzFytQhAppJGHn5Sq1lTPZrKjegz5NrVmr_oVsiLT5NRbtn11EtzCd.DPgQOUEsPYfz0LfoMEeNqw.C2lhVJ6Gc1aGZg-CVUYyTkgCdiDo_yZtfuSogL2DGWRPsPlj8vk9Vd8pq9KpqpqsMS3aUHE4vyqw_IcbpbXold-J3GwL1m7KYVZFWkM88ewjzFxptMOwF07srjJ0Hjs_wHP9__dxKl-MBwXHVCQ3d4usiV8m-2QVy1QXQI5k2gCaK9c6SZgR9DxIJNeEpmmcZ-yCcvYnFy503am1iRIAkxfGMIlhErlYnEM_bTMjLz68NWH3-2tGjU7gVxgfjoEL.1fArMDRneEfLyc52H_9nb6d2OSL32UC3LTL2T-8i8_w',1,'2026-11-09 20:35:49','2026-11-16 20:35:49',NULL,NULL,NULL),(42,3,'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.S2jFyij8_V8r06faqZ3oNpSQrOYftKnuW3wEE6EIFKbDzdUovWHDqbCj4SN_NHajBvxXR665vmYBjPDcqAkqbcr8-rhJ4RhZ.u7beyIW79sLw_Dta9RL7Cg.mGO6CMJRUMc6xwToWNdASWXZaimiq1-FZVYuMFE6nvQzwl0yXuHSjuYn4mML-0uiSqKd12FJhJ41zgyIPq7UjmXFMVzWRdThgJSuF2oaUH6srtleFUnM-YuUNsy3wt9UyjBevPWpCcPs8OxpRiv7UkOJHC6B8CzZQhEXd7vbME1bdNy40PaXDHGpJZikHHv-9Q_Tnj5DunIEuwYX6ufRBOSCHqApYyQEts7sx-ITH7o.GtSvfqUutcz1iQVJ51wQ18Yo6PvJEEGSZm55z1cg-tw','eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.ncKP-t8TcGMBjmZ7pPSsa8vM6BQvL5lYfePgAmmZJloZ0K3cVivYhQmct8kX-m2xyw9RaP5Vf-XZ8kG9vdk6mSHQYSDhAsuL.5PRQKn69W1wW2mXW63u0zg.uIxJvKu3pV0G5OiXWEEiIgploxAHeSszgd4RKMKAapo74dYH1ttjhi2Xa_KIaHaJP6FfnHEU2L7XPI0wakrjc74QLK-03_c56WSlo8MpH7RuxJ-UEPWVWyhL_oqDCNbgPys0VgoKe4no7wkEPH1Oz4Qa_v9Fyu_6VfwcI4M3Ng9QyEaklEFSejIggoKob4QPVgwF3_wSri4yeMg-_TMdTy6zQHipFw4N0qTQZpdLEbkMaZvmb-0Z2jahVNELkufcuaUXDBdYRXs6UUc98t6_aw.V7qfkdrSN5sN0_L88kxT-wtTTLYlOQjspeCNnOJN0GA',1,'2026-11-09 20:44:31','2026-11-16 20:44:31',NULL,NULL,NULL),(45,3,'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.YrnDJARtVeIwvPP4sobvcdO_VleljSLwVGLQnkNSAmWvnvlZyKKfUuEx7ZR9h1ua9yKEVhCZH-KSXmSUPt1jtz4rK3xj_3Ac.uu58JupTnbP7kZlfMGV6gg.FZyb5ud4PYVLjuh2TRAsqYmB0VAfEon9AqDqXr5Ac3WXy6A3kuj_Fsq2t9fAdoRO8pKVOp2OYW6LuZLgJv3I1s8xjW3-jyLoduKnaeNvjLp9cSLXRbumvJ2R6Oiz3xfevmTSTZLgdakWV-W9j-c1J-PwJ3PjpoKzA2xt8xHhHsDkBoWP7mdZmX-AomYOLstlS08t0szQnSoVvNgyFWHVZpMzcN9gsyl9sxF8aeLg8eA.DpT1BrZHU2OqoddLnkcGFmJM8XeCKOsJdChNHv-tgGg','eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.8ewyg3yJNaYieD7hZq0pGjSI-x7EnuPyXM2LIOx9itlc85ygNE3Ssy9u9PKm7-Vfj9JZAmQyu5DekE3S4LJMsNbUzZtAIzyi.yIKXbO4dG-pzn69vsKSksQ.z4qiAbUBTWm3akaJxBefvp2cyTfe5Yxjwv30qYZN6x3avE-67tDGXIa61bDFx82B_1stb0DDx8tf2QRtkFXhe4KI8OqK2sG4Gb3ndaxQWN1Op1Uj0_x0b5vOHOSRlUMirfmX2D6yNfKtMS0bunOttdeyQOeLQ0WXcpN8yS6Ooea7EI2wcXg8Hymp1_XLQSUuiT-8fYSRUdFIpv2ZU_jrr_RBN_br3cJTr7IoRiQy73HyLjbzXsLyVBuuC7OzAQChTqIGog8-YgIn7h4f6VGj_w.UFj-Nkd0BvwgEAkrYgl2RW1Imc99KkqTzBc8iV8i1aM',1,'2026-11-10 20:31:26','2026-11-17 20:31:26',NULL,NULL,NULL),(47,2,'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.r4Cb-pbq2OvqiLx5Q1TVSMB8zEIkz9rfbuDdComJ4IVslpG_B0sh06xaMXFQfgeIfB0Jm8baSWMXmQEdYo7_VymKxglqnTaU.zKHOaYWxVu3dMir4XT0VsQ.ZkCGubJNmPrxvUoGYGw1APf8kpBsccW2EMOnb3vaPRDdXDjspNPJda4YUUouw1qDcS_g3-xs85AIMLYI0KfPsnuXK5hb6dfEPeeriDKhRXRvYG7FguH2PtgFbsZmnuvUqhLrDNSPH2qOwuJ6VtepA0YFrrTf1hShwR2Pl12ZdbOrItBFrOgNHkoA-Z2w10IeAwj1L08M4z5TeHbvC5-XlOOtN8ditcF5lJ6r4VSxM4gY-5QcTPxwBP5mxCL4ixR2.7gicuyQ9DlFlLhklXXiHJdtyND9CodkSSzzOOjBrXOE','eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.7XKGJLGsbWLgEICOOnxnItoeKnSzFxIS50BTFOm7JxilBYqNsPGHggwPD65KlMMCMEZNTciLqvFpZsjkEwH7B7j-F4TPJGWX.PMCaWWdNv3wSebaWkPUjlw.zb-hOP0dvfTwdI-UmTjwC9tcv_JzvrulVvqsnTmViAfNJ4U3i29_okIiD7WlLi8AOxpLTNK3Nx3gFekqVl6nKP9_1YHn46T_tA2fFCIGQ_p7IDV-TkKRWMCJIfmT_Ffc27sSTkdtrpJnNo0O61uxxVty5-jQDTwAiKS-Zm4p6ZUYI0VViLxPdzdlPPFi5eVdzHm6TY3fHJvIwYy76pb_gHNGcyus9MPEdIOQAaJs_K8NmWyt-t-TvUDXU5nQkAtxqWamEUOHWWUT9uB5C9zi89AGBAchV5Tn8VYiAvb39T8.eOi18M8rNRfiIjOHu64Kbi2Y_QYY',1,'2026-11-10 20:33:36','2026-11-17 20:33:36',NULL,NULL,NULL),(48,2,'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.fwmkWExC-HZJsxRXwtqfHhU0KNWmbRg477_ORSabc0cObudbGmuWYGIujyS3gQBBhgOyIy7V5nU3taspcBQ5_UT1rl_0_AiQ.qEJxJacOcdb8SpVvdp-wdA.Op7bFHq94T5THfCf1aotogs3hSRShWLrZ1IOVul3FBgJVkpRmxG7m0N4MxkFM2UJ2tVO3AfIHb_18pxRQDGg3FgqoPpPPsUmX0StPi9GInttLSTJnTSLwxlsLewsgBg7qlj4aCYKdAXu99f8pOhZeq9T3OKXEQtCIjEP6IFbrS7QIuXkpMH1QwqJb550rorMzYCZ0zkxmRmJXdskJ4bQlE0pxwZ9I7ErleiJXPeAzpR4_NgTn76Kgf9yTtwn5I1v.7CeITnYqhi3RGZI7MUNQ4CZurMSf__i4t1Mftdp77RA','eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.EBUeBQ4ITOaH3FUTDJkxKakdH3MgKtRUBoPo2DyN7deQPRUMmKAM6uMVEufzyw7mCyJU9Bqai_t34WEu1NHkppRf7vrjfCA8.z1Xqts1vXZCkDV0kxfJY0Q.Fh1G4B93nexF2SZ0muE0UEL3as4Gdj9FKyH1xADnBQ_h8pn2Gp9IB8hGohIXtbyIQCUvn_5szgkYO7xDg5pEoq6Z9LaoIVR3lRp1N7Ctss7K6tGHgFqahv0szvfikhbsUmfyZYEIni-36xd6SXJqVCleVvoddzq0n2aTTjOv19RquWSTjB65wN89yJvzGS1as3gvSOSH3Y9VL58x6z3IKh4iT2diXoVvB137HVTalgoOEwdaHJHBApMBKBgucqUP9XLSIP4mxRo3vTX4mulJAE3_22X2XcsX6GPWdo9t5Rs.D5ELrhJD8YVQLiea8svycoEyw7dr',1,'2026-11-10 21:19:52','2026-11-17 21:19:52',NULL,NULL,NULL),(51,2,'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.TljdcP_lDv28N8t3wG2PFS5GSslKOhZrzuUqoDil0spNhj53nRmtyJQwQQ25uMDETg9nnrudO6rF0a6m3xFB9H5VLcqoNfIO.c8Sw4laGfRrSpVIKD_ywsw.MGryAwMgEvr8VJo_bOKzZUi8DAm8Wbbgkmx2XDZhIN7gSdrqIy0CfaLZAXJy5pEpS_Gq0i9vsIBTHI-fzMZHUPUBrxGzXZEJPa72cjLGlKGhvuAX8Bq7aewDZiXUniu1wSsWIxSvW1TqqsAYB55si68uMa1EZghVJKq97ew-PlQJzc-6R412njiJLN6ixvrFsxPawts6nmk0Bf7lYMihU-rCOrk5lL3pW0AHM9AHVJ_NiYkbDnlVtbx6Q3y1tAQf.QdrAfe4QtnBuh6H2fu8GVbHFPXgaD8r1y8Dxx7HEiok','eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.dn3Oxl4xtkzHiBX0GlzOIej29aFtz49btrLWTjK1uyFN3NjHgsmYzgrSTgBVSWlLSanK1MqefQhihMJT9u097tNReYSixX61.Hf2i5yEOXm6VjTlk769IGw.cVEd5ORCyp61WmrdcBd9acdzb_wJQF-0KHNjW6qsosyUEWUVUVvXRrFDrmRo0wxIXwj3QGuCO0GDT_r1dgZJ7YnK01zMKv4lhPddH23sBmB3kjiB8KAtXQkj4CagY3y_bm2G4972qk0rMt4ZaAU8qUa3guQTLAyhvb6Up6ZxHCA2tcdhMcNSTxTBPDh5iXjhabQo-lUddB2CPpcVfxA9VG7FXyHAwi7xpUHC9KophIDh7RKV2b0yk7mvFYnS_YYFMfHAWN-HurpJOBtdPdHtWvWdXiYW_B35Zc_Y9QyQhps.cJFihRhc0WGnYbORca1KomAZF1Qs',1,'2026-11-11 15:17:47','2026-11-18 15:17:47',NULL,NULL,NULL),(52,1,'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.UnXhwwYY1wNv3ZTYWR9qsVcgxQQZ1lSt5vmLdvMx1yYK7m8qeUbqx2w6dCll1fp5q6FP51OlKIwK8mCusfK43UyYOHk0p0Ys.p_15wgm24_8_SDE98jcgtg.0XtYDQdx026BoWrcvehjMI_NTv1fe-ycoK8lg4tjm05_mg3kz53idhl2-EpRtTlhFsPe7VTvWDKW2gGZ8LBkFWf-Tlfg4R53agLl-OIdW1dU8Y6ej-0P0ddgaCYJCQpl5UHPN50KMmYO0HmOdGr4k6-juSU-R0iMqvFFHRXSB2wJm0jGLe4_5BHJf8Pgf3xTo9J6pMMjbF6yyBeeh26CS48j8_LnZfKjtn2j8PlhWQo.1AzhlDsflaBSE8snbDOrpBz7LE2AMCE4AitrWx-LfJ0','eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.mpTdj3TmqpfE1l0WWrscrSjaf0sHi3BB4exwz0IaExW1GOrpLCffya2FemQaQwSUKbjWygnpeUEwv8IzkNUKyUkqTzIu6ZBc.-1leSRrYyaCSmO8lxPwqUw.yL2GLJEeQkUmGDq0SHdtkgQTF0xAY37TWEaRHpumdlec_r0qT69AHT-QUBhMVMe1YvHHTX-UShx_BXqx-hst4ixg7Ulb0tOVcL77JTImQKMJm1p6UTg0ZfmP41ck8IoYAz8Cv78RJ13ylnlep5FYLG1wOIqHiUaWI9hGjIRfePIqWdEmSZVDywrSsCCiJEsVCAmqLjQ03L1s4NMo0FlqplOQ-SqoJvYUksxqT7hFrb8Oa3OnVPh9wBTxZGpvJRr7.Ubs64-eiXTa6UfOBusHGGvSqqVSXNbIbRRQFs8e4qrs',1,'2026-11-12 21:32:16','2026-11-19 21:32:16',NULL,NULL,NULL),(53,1,'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.YUprU4-hjGt8nlaASDMJW1u4SCsfdmXaE4CRoeGFUBv1tqWJX0soUTfm3Jhuynoa5ih4F9jNUyaytGSJGunWlWf1hcyA3dgp.Yewy-Psek7DJjVMqRfxPHA.kq3-rT60WXPBaYWikwpHNiwtaRiDgx1v2mBwWSOPTvdvTp0qNjJSgT-MIP7a4ion1Qu_DCrTHQZO0etIL6d2SqzZW2578FAeL-cqmJV4pz0NA0_oETHe4SJjDPumsJE4bt7mHNo8BQdJ_7yuckBYmd5aGQOVWtmbJ2j0e0HgyC7omrAV0rMvjkhZkyNfM5SU4tJnU8TPonwP820QQtYRFCqw6wQGpqEaPtUyihrkpf0.MCQP8TpEPQRwoo-9OltfKI_lV0hVv5Igx4IlakT45_I','eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.6wndQLsbKYWAwVEeyfx1pnAqiXEWrXG4H6PD8fmiu9z2a7UWoqVfDyhKpi97iE-SudSdjqS-kxk8jSMa7QZk7NZgmt9ik3iH.H34BIW6hrPKHtI0HlJgMQQ.hW_qmc7SberYpFMbIEYmS4GW2ZtCT82pcnygQxiHO5u27CXnx7W0t9IXScW-pLRmJb4kE6UcAckLE3WzCukHfEuuh_pDiUbWSFBlCmsPylUSduhwRSaK1oInvv4aQRXYvE9k3KZwvqYsAt5Zs8BRLIAIAouQNM6DdTrCyihOM3zNkl4Rcxpb-iI66gmt0BjKKWmQzlVjME5sxVQl1Wy6HSDvvTD3FWj9-7rJ6PYDH0cJjBZVd4feMcwarggcZiMv.Xa1fGua1JwRMvr16-7NBxEwn3eyju1ayCYKh40SHll4',1,'2026-11-18 16:18:08','2026-11-25 16:18:08',NULL,NULL,NULL),(54,2,'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0._OYeQRlvYiHJBWMcM0mZokwi7gFzPgL9B9w9kXkwZA6B5zjQzPPXIZ9sQ_SDfWOFRdPiR9t830alHDiHq0zQhosLWvQs75Ac.3MlAxxjUYQS289_lUBh-fA.LXIlFYmAgBUrEYEfGQ8T5tkkHSuFBImgkjQAsCm0OSwKy7nC196VZ2mrKEqkHtDyMhBWuapKst3rRzJX8HhRGj4J7_d_Qhp0cPsnqFOW80u5K5BckNlUxwpfj2BaUzduFlNwc8YJZv_G1LaqPaqL4B1ghE2bwIJC2c8RWunCDd8FPusOTnLmsKdDdFuFIV5ZAk6xqApivHDPdCewmkbFYbwY4sbXlW92dF2r0qT82FaenwBNBDfwEnlyJjpFE7Cw.q9QnxmVZXIFk2mhoQbtl5nsQKk08vvV1mQAoHndOd8w','eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.9IMkWV65vS09a-gnqHBpiVI6xBBa3D2TrzzUAxSwLcAbi-2EF3znpM5pDHwAFezzbUpScT0z2Gm5JOyYqn379T4c07ZDiKu8.jj3TvJJ9Hpt2XUzxXUY0Lw.qkh4Jjt9pU_Aw7-JyYq0l_nENLwk8b6sc6QM94q-rut0OTkJEsIekBwcRKC833q7mkjzaUcj-STaMLUTxyNr7gANWFI8f_VHRr0I_BGblxaTykAT1WZg2ic1TEu0ZCkxLvzQUeKDLLRk4sudKGBdwgc0iOPL57mkimK0b1hkxQeFlqFRRYRVUmfwQ-7J2qo0QpXulwHXwRcQz13Sse6eG_S6q3xm9DSIJ5HtW5-iHW1zSzPv33Mcl9MmL03i3_IFjfhUJbNmQWe8MyzHsY615_U4Qq_DFfMyaTThJ7F3WFM.RmKW-28_cttUZcmHNs8GsdkRZHBS',1,'2026-11-18 16:18:44','2026-11-25 16:18:44',NULL,NULL,NULL),(55,1,'eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.lA9ueCupl-PznqNOuX1SFWz2MH7FoTKRqh4yQ_LcHGy4VEQYQEgwm4G9DWhYNi77z5LuUOxKHHXueh5R367QnNbfCWlFUtEa.8AOGpUYlfDfox_a-7AZj7A.kg2X5bDFkXCIpiUwXxfidzb2ayM1aujEo4IkPexAsUwFIY1pH7lVUS_evj0Dnis-tMzW93q7XTateT_SGDzk3EVPRRhu-ztujUM5UISJTizq0F4ib5DPUr1G4FAphbitvkN0bgsdRLm7PKmPjaXs6r5YGhsR3AcrlxROI2gdKdaWiuS8pafhF-MfftvEI4XAv3V7jxK8ZH6RFilHZdXDxbQSztXhN509LldYfvzVX40.NNF8HK1SsrwUxAmaEOnv0M92ArbHiOamP7Q-MLYTzrw','eyJhbGciOiJBMjU2S1ciLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIn0.Tc35D5T0YLKirX_pGnPv-roF6RD6Z3QczwRjcwDonnK6PSZhasavu-rxcalzp43mnpEN0wOwy-jKwBTAb5FhP-4_yzipb1WX.1ryKRv0W9xFjQ0h1Do9OdQ.D0aL8_cQVvNBuXiccAZ8nHvoLxPJEaYRZU7Jcgg2mQ-v9FcHD94PXWBdi_M494WpGEcnU082zp23yAR8K9LP_FckOTrbfBWxONDxphnx7zc4kYCkXif05zhAhv7umm7Zqf-20bVRkqpdKJUv2Ba5T0A1iXXn2ooW_Bg0a7S5fM3uHcYZnMwhVLH1O2Iza7ZOa8TP-66ziNbSfG6CQKXeotu4tPqSm0YfqYEMMU0HzyatahComnmKPpYL8Q7M0rDL.a63Mk3VBgfqDaQYy-W6qgL57fzsJwO5jeKxSGk4ct24',1,'2026-11-18 21:36:17','2026-11-25 21:36:17',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36');
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transacciones_pasarela`
--

DROP TABLE IF EXISTS `transacciones_pasarela`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transacciones_pasarela` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cuota_id` int(11) NOT NULL,
  `monto` float NOT NULL,
  `pasarela` varchar(50) DEFAULT NULL,
  `estado` enum('pendiente','confirmada','fallida','expirada') DEFAULT NULL,
  `referencia_externa` varchar(100) DEFAULT NULL,
  `url_pago` varchar(255) DEFAULT NULL,
  `motivo_falla` varchar(255) DEFAULT NULL,
  `pago_id` int(11) DEFAULT NULL,
  `creado_por` int(11) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `fecha_confirmacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cuota_id` (`cuota_id`),
  KEY `pago_id` (`pago_id`),
  KEY `creado_por` (`creado_por`),
  KEY `ix_transacciones_pasarela_id` (`id`),
  CONSTRAINT `transacciones_pasarela_ibfk_1` FOREIGN KEY (`cuota_id`) REFERENCES `prestamo_cuotas` (`id`),
  CONSTRAINT `transacciones_pasarela_ibfk_2` FOREIGN KEY (`pago_id`) REFERENCES `pagos` (`id`),
  CONSTRAINT `transacciones_pasarela_ibfk_3` FOREIGN KEY (`creado_por`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transacciones_pasarela`
--

LOCK TABLES `transacciones_pasarela` WRITE;
/*!40000 ALTER TABLE `transacciones_pasarela` DISABLE KEYS */;
/*!40000 ALTER TABLE `transacciones_pasarela` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `hashed_password` varchar(255) NOT NULL,
  `rol` enum('admin','prestamista','usuario') DEFAULT NULL,
  `estado` enum('activo','inactivo') DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expires` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `ix_usuarios_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Administrador','admin@test.com','$2b$12$Na3.dMjB1h68Yy6fBR.Uw.gTAoqw//2uJaO.FDUfY2fEDUFA9aV6m','admin','activo',NULL,NULL,'2026-09-17 16:15:06','2026-09-17 16:15:06'),(2,'Camilo','camilojara0000@gmail.com','$2b$12$ApjIMbtBQ8N2dJLI3WiRpui2cGTZYgBo0SBVxxQA.CTTTGygec1xG','prestamista','activo',NULL,NULL,'2026-10-30 17:29:40','2026-11-18 16:18:31'),(3,'Andres','andres@prueba.com','$2b$12$G0qw3anxI/D9nqLmCJmIG.zDls6uezoNDB6eI/uH2wuoULuI22VgK','usuario','activo',NULL,NULL,'2026-11-09 20:35:07','2026-11-09 20:35:07');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'loan_soft'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 17:14:41
